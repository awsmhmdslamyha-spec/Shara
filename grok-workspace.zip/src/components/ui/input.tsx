import { type InputHTMLAttributes, type TextareaHTMLAttributes, forwardRef } from "react";
import { cn } from "@/lib/utils";

export const Input = forwardRef<
  HTMLInputElement,
  InputHTMLAttributes<HTMLInputElement>
>(function Input({ className, ...props }, ref) {
  return (
    <input
      ref={ref}
      className={cn(
        "h-11 w-full rounded-xl bg-elevated px-3.5 text-sm text-fg placeholder:text-subtle",
        "shadow-[var(--shadow-border)] outline-none",
        "focus:shadow-[var(--shadow-border-hover)]",
        className,
      )}
      {...props}
    />
  );
});

export const Textarea = forwardRef<
  HTMLTextAreaElement,
  TextareaHTMLAttributes<HTMLTextAreaElement>
>(function Textarea({ className, ...props }, ref) {
  return (
    <textarea
      ref={ref}
      className={cn(
        "min-h-24 w-full resize-y rounded-xl bg-elevated px-3.5 py-3 text-sm leading-relaxed text-fg placeholder:text-subtle",
        "shadow-[var(--shadow-border)] outline-none",
        "focus:shadow-[var(--shadow-border-hover)]",
        className,
      )}
      {...props}
    />
  );
});
