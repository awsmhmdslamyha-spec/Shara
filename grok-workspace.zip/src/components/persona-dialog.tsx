import { Copy, Plus, Trash2 } from "lucide-react";
import { useEffect, useMemo, useState, type ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Input, Textarea } from "@/components/ui/input";
import { FRANKNESS_HINT, FRANKNESS_LABEL } from "@/lib/defaults";
import { useSahraStore } from "@/lib/store";
import type { Frankness, Persona } from "@/lib/types";
import { cn } from "@/lib/utils";

function Field({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-medium text-muted">{label}</span>
      {children}
    </label>
  );
}

export function PersonaDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const personas = useSahraStore((s) => s.personas);
  const activePersonaId = useSahraStore((s) => s.activePersonaId);
  const upsertPersona = useSahraStore((s) => s.upsertPersona);
  const createPersona = useSahraStore((s) => s.createPersona);
  const duplicatePersona = useSahraStore((s) => s.duplicatePersona);
  const deletePersona = useSahraStore((s) => s.deletePersona);
  const applyPersonaToActive = useSahraStore((s) => s.applyPersonaToActive);

  const [selectedId, setSelectedId] = useState<string | null>(activePersonaId);
  const selected = useMemo(
    () => personas.find((p) => p.id === selectedId) ?? personas[0] ?? null,
    [personas, selectedId],
  );
  const [draft, setDraft] = useState<Persona | null>(selected);

  useEffect(() => {
    if (open) {
      setSelectedId(activePersonaId);
    }
  }, [open, activePersonaId]);

  useEffect(() => {
    setDraft(selected);
  }, [selected]);

  function patch<K extends keyof Persona>(key: K, value: Persona[K]) {
    setDraft((d) => (d ? { ...d, [key]: value, updatedAt: Date.now() } : d));
  }

  function save(apply: boolean) {
    if (!draft) return;
    const next = {
      ...draft,
      name: draft.name.trim() || "بلا اسم",
      updatedAt: Date.now(),
    };
    upsertPersona(next);
    if (apply) applyPersonaToActive(next.id);
    onOpenChange(false);
  }

  if (!draft) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent title="شخصيات المساعد">
        <div className="grid min-h-[28rem] md:grid-cols-[220px_1fr]">
          <aside className="border-b border-border p-3 md:border-b-0 md:border-e">
            <Button
              variant="outline"
              size="sm"
              className="mb-2 w-full"
              onClick={() => {
                const id = createPersona();
                setSelectedId(id);
              }}
            >
              <Plus className="size-4" />
              شخصية جديدة
            </Button>
            <ul className="space-y-1">
              {personas.map((p) => (
                <li key={p.id}>
                  <button
                    type="button"
                    onClick={() => setSelectedId(p.id)}
                    className={cn(
                      "w-full rounded-xl px-3 py-2 text-start",
                      p.id === draft.id ? "bg-elevated" : "hover:bg-elevated/50",
                    )}
                  >
                    <div className="truncate text-sm font-medium">{p.name}</div>
                    <div className="truncate text-[0.7rem] text-subtle">
                      {FRANKNESS_LABEL[p.frankness]} · {p.tagline}
                    </div>
                  </button>
                </li>
              ))}
            </ul>
          </aside>

          <div className="space-y-4 p-4 sm:p-5">
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="الاسم">
                <Input
                  value={draft.name}
                  onChange={(e) => patch("name", e.target.value)}
                />
              </Field>
              <Field label="جملة تعريف">
                <Input
                  value={draft.tagline}
                  onChange={(e) => patch("tagline", e.target.value)}
                />
              </Field>
            </div>
            <Field label="الدور">
              <Input
                value={draft.role}
                onChange={(e) => patch("role", e.target.value)}
              />
            </Field>
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="النبرة">
                <Input
                  value={draft.tone}
                  onChange={(e) => patch("tone", e.target.value)}
                />
              </Field>
              <Field label="الأسلوب">
                <Input
                  value={draft.style}
                  onChange={(e) => patch("style", e.target.value)}
                />
              </Field>
            </div>

            <div>
              <div className="mb-2 flex items-baseline justify-between">
                <span className="text-xs font-medium text-muted">مستوى الصراحة</span>
                <span className="text-xs text-fg">
                  {FRANKNESS_LABEL[draft.frankness]}
                </span>
              </div>
              <input
                type="range"
                min={1}
                max={5}
                step={1}
                value={draft.frankness}
                onChange={(e) =>
                  patch("frankness", Number(e.target.value) as Frankness)
                }
                className="w-full accent-accent"
              />
              <p className="mt-1 text-[0.7rem] text-subtle">
                {FRANKNESS_HINT[draft.frankness]}
              </p>
            </div>

            <Field label="الحدود">
              <Textarea
                rows={3}
                value={draft.boundaries}
                onChange={(e) => patch("boundaries", e.target.value)}
              />
            </Field>
            <Field label="تعليمات إضافية">
              <Textarea
                rows={4}
                value={draft.instructions}
                onChange={(e) => patch("instructions", e.target.value)}
              />
            </Field>

            <Field label={`الحرارة ${draft.temperature.toFixed(2)}`}>
              <input
                type="range"
                min={0.2}
                max={1.2}
                step={0.05}
                value={draft.temperature}
                onChange={(e) => patch("temperature", Number(e.target.value))}
                className="w-full accent-accent"
              />
            </Field>

            <div className="flex flex-wrap items-center justify-between gap-2 border-t border-border pt-4">
              <div className="flex gap-1">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    const id = duplicatePersona(draft.id);
                    setSelectedId(id);
                  }}
                >
                  <Copy className="size-3.5" />
                  نسخ
                </Button>
                {personas.length > 1 ? (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-danger hover:text-danger"
                    onClick={() => {
                      const next = personas.find((p) => p.id !== draft.id);
                      deletePersona(draft.id);
                      setSelectedId(next?.id ?? null);
                    }}
                  >
                    <Trash2 className="size-3.5" />
                    حذف
                  </Button>
                ) : null}
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => onOpenChange(false)}>
                  إلغاء
                </Button>
                <Button size="sm" onClick={() => save(true)}>
                  حفظ واستخدام
                </Button>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
