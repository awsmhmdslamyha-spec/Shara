import { Eye, EyeOff, Lock } from "lucide-react";
import { type FormEvent, type ReactNode, useEffect, useState } from "react";
import { Crescent } from "@/components/logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  GATE_LOCKED_EVENT,
  clearGateToken,
  gateHeaders,
  getGateToken,
  setGateToken,
} from "@/lib/site-gate";

type Status = "checking" | "locked" | "open";

export function SiteGate({ children }: { children: ReactNode }) {
  const [status, setStatus] = useState<Status>("checking");
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let cancelled = false;

    async function check() {
      try {
        const res = await fetch("/api/gate", {
          credentials: "include",
          headers: { ...gateHeaders() },
        });
        const body = (await res.json()) as { ok?: boolean };
        if (cancelled) return;
        if (body.ok) {
          setStatus("open");
          return;
        }
      } catch {
        if (cancelled) return;
        if (getGateToken()) {
          setStatus("open");
          return;
        }
      }
      clearGateToken();
      setStatus("locked");
    }

    void check();
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    function onLocked() {
      setPassword("");
      setError(null);
      setStatus("locked");
    }
    window.addEventListener(GATE_LOCKED_EVENT, onLocked);
    return () => window.removeEventListener(GATE_LOCKED_EVENT, onLocked);
  }, []);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (busy) return;
    const value = password.trim();
    if (value.length < 4) {
      setError("أدخل كلمة السر.");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/gate", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password: value }),
      });
      const body = (await res.json()) as { ok?: boolean; token?: string; error?: string };
      if (!res.ok || !body.token) {
        setError(body.error ?? "كلمة السر غير صحيحة.");
        return;
      }
      setGateToken(body.token);
      setPassword("");
      setStatus("open");
    } catch {
      setError("تعذّر التحقق. أعد المحاولة.");
    } finally {
      setBusy(false);
    }
  }

  if (status === "open") return <>{children}</>;

  return (
    <div className="flex min-h-dvh items-center justify-center bg-bg px-5 text-fg">
      <div className="w-full max-w-sm">
        <div className="mb-8 flex flex-col items-center text-center">
          <Crescent className="size-11 text-accent" />
          <h1 className="mt-4 font-display text-2xl font-medium tracking-tight">سهرة</h1>
          <p className="mt-2 text-sm text-muted">هذه المساحة مقفلة</p>
        </div>

        {status === "checking" ? (
          <p className="text-center text-sm text-subtle">جاري التحقق…</p>
        ) : (
          <form onSubmit={(e) => void onSubmit(e)} className="space-y-3">
            <label className="block text-sm text-muted" htmlFor="site-password">
              كلمة السر
            </label>
            <div className="relative">
              <Input
                id="site-password"
                name="password"
                type={show ? "text" : "password"}
                autoComplete="current-password"
                autoFocus
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  if (error) setError(null);
                }}
                placeholder="أدخل الكلمة للدخول"
                className="pe-11"
                aria-invalid={Boolean(error)}
              />
              <button
                type="button"
                className="absolute end-2 top-1/2 inline-flex size-8 -translate-y-1/2 items-center justify-center rounded-lg text-subtle hover:text-fg"
                onClick={() => setShow((v) => !v)}
                aria-label={show ? "إخفاء كلمة السر" : "إظهار كلمة السر"}
              >
                {show ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
              </button>
            </div>
            {error ? (
              <p className="text-sm text-danger" role="alert">
                {error}
              </p>
            ) : (
              <p className="text-sm text-subtle">الدخول لمن يملك الكلمة فقط.</p>
            )}
            <Button type="submit" className="w-full" size="lg" disabled={busy}>
              <Lock className="size-4" />
              {busy ? "جاري التحقق…" : "دخول"}
            </Button>
          </form>
        )}
      </div>
    </div>
  );
}
