import { Copy, Check, RefreshCw } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { MessageMarkdown } from "@/components/markdown";
import { STARTERS } from "@/lib/defaults";
import type { ChatMessage, Persona } from "@/lib/types";
import { cn, isMostlyArabic } from "@/lib/utils";

export function EmptyHero({
  persona,
  onPick,
}: {
  persona: Persona | null;
  onPick: (text: string) => void;
}) {
  return (
    <div className="mx-auto flex w-full max-w-2xl flex-1 flex-col items-center justify-center px-5 py-10 text-center">
      <div className="sahra-enter">
        <div className="text-4xl font-medium tracking-tight sm:text-5xl">سهرة</div>
        <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-muted">
          مساحة حوار خاصة لراشدين. بلا سقف موضوعي مصطنع، وبلا ردود سطحية —
          غيّر الشخصية كما تشاء.
        </p>
        {persona ? (
          <p className="mt-2 text-xs text-subtle">الآن: {persona.name} · {persona.tagline}</p>
        ) : null}
      </div>
      <div className="mt-8 flex w-full flex-col gap-2 md:grid md:grid-cols-2">
        {STARTERS.map((s, i) => (
          <button
            key={s}
            type="button"
            onClick={() => onPick(s)}
            style={{ animationDelay: `${120 + i * 40}ms` }}
            className="sahra-enter rounded-2xl bg-elevated px-4 py-3.5 text-start text-sm leading-relaxed text-muted shadow-[var(--shadow-border)] hover:text-fg hover:shadow-[var(--shadow-border-hover)]"
          >
            {s}
          </button>
        ))}
      </div>
    </div>
  );
}

function UserBubble({ content, images }: { content: string; images?: ChatMessage["images"] }) {
  const dir = isMostlyArabic(content) ? "rtl" : "ltr";
  const [open, setOpen] = useState<string | null>(null);
  return (
    <div className="flex">
      <div
        dir={dir}
        className="ml-auto max-w-[min(100%,42rem)] space-y-2 rounded-2xl rounded-br-md bg-elevated px-4 py-3 text-[0.98rem] leading-[1.7] shadow-[var(--shadow-border)]"
      >
        {images?.length ? (
          <div className={cn("grid gap-2", images.length > 1 ? "grid-cols-2" : "grid-cols-1")}>
            {images.map((img) => (
              <button
                key={img.id}
                type="button"
                onClick={() => setOpen(img.src)}
                className="overflow-hidden rounded-xl text-start"
              >
                <img src={img.src} alt="" className="max-h-64 w-full object-cover" />
              </button>
            ))}
          </div>
        ) : null}
        {content ? <div className="whitespace-pre-wrap">{content}</div> : null}
      </div>
      {open ? (
        <button
          type="button"
          className="fixed inset-0 z-50 flex items-center justify-center bg-bg/80 p-4"
          onClick={() => setOpen(null)}
          aria-label="إغلاق الصورة"
        >
          <img src={open} alt="" className="max-h-[90dvh] max-w-full rounded-xl object-contain" />
        </button>
      ) : null}
    </div>
  );
}

function AssistantBlock({
  content,
  streaming,
  onRegenerate,
  showRegen,
}: {
  content: string;
  streaming: boolean;
  onRegenerate?: () => void;
  showRegen?: boolean;
}) {
  const [copied, setCopied] = useState(false);

  async function copy() {
    try {
      await navigator.clipboard.writeText(content);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1400);
    } catch {
      /* ignore */
    }
  }

  return (
    <div className="group">
      {content ? (
        <MessageMarkdown content={content} />
      ) : streaming ? (
        <p className="sahra-shimmer bg-clip-text text-sm text-transparent">يكتب…</p>
      ) : null}
      {streaming && content ? (
        <span className="sahra-caret ms-0.5 inline-block h-4 w-1.5 translate-y-0.5 rounded-sm bg-accent align-middle" />
      ) : null}
      {!streaming && content ? (
        <div className="mt-2 flex gap-1 opacity-100 sm:opacity-0 sm:transition-opacity sm:group-hover:opacity-100">
          <button
            type="button"
            onClick={copy}
            className="inline-flex h-8 items-center gap-1.5 rounded-lg px-2 text-xs text-subtle hover:bg-elevated hover:text-fg"
          >
            {copied ? <Check className="size-3.5" /> : <Copy className="size-3.5" />}
            {copied ? "نُسخ" : "نسخ"}
          </button>
          {showRegen && onRegenerate ? (
            <button
              type="button"
              onClick={onRegenerate}
              className="inline-flex h-8 items-center gap-1.5 rounded-lg px-2 text-xs text-subtle hover:bg-elevated hover:text-fg"
            >
              <RefreshCw className="size-3.5" />
              إعادة توليد
            </button>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}

export function MessageList({
  messages,
  streamingId,
  persona,
  error,
  onPickStarter,
  onRegenerate,
}: {
  messages: ChatMessage[];
  streamingId: string | null;
  persona: Persona | null;
  error: string | null;
  onPickStarter: (text: string) => void;
  onRegenerate: () => void;
}) {
  const scroller = useRef<HTMLDivElement>(null);
  const bottom = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottom.current?.scrollIntoView({ block: "end" });
  }, [messages, streamingId, messages.at(-1)?.content]);

  if (!messages.length) {
    return (
      <div className="min-h-0 flex-1 overflow-y-auto scrollbar-thin">
        {error ? (
          <div className="mx-auto mt-4 max-w-xl rounded-xl bg-danger/10 px-4 py-3 text-sm text-danger">
            {error}
          </div>
        ) : null}
        <EmptyHero persona={persona} onPick={onPickStarter} />
      </div>
    );
  }

  const lastAssistant = [...messages].reverse().find((m) => m.role === "assistant");

  return (
    <div
      ref={scroller}
      className="min-h-0 flex-1 overflow-y-auto scrollbar-thin"
    >
      <div className="mx-auto flex w-full max-w-3xl flex-col gap-6 px-4 py-6 sm:px-6">
        {messages.map((m) => (
          <div key={m.id} className={cn(m.role === "assistant" && "pe-2")}>
            {m.role === "user" ? (
              <UserBubble content={m.content} images={m.images} />
            ) : (
              <AssistantBlock
                content={m.content}
                streaming={streamingId === m.id}
                showRegen={lastAssistant?.id === m.id && streamingId === null}
                onRegenerate={onRegenerate}
              />
            )}
          </div>
        ))}
        {error ? (
          <div className="rounded-xl bg-danger/10 px-4 py-3 text-sm text-danger">
            {error}
          </div>
        ) : null}
        <div ref={bottom} />
      </div>
    </div>
  );
}
