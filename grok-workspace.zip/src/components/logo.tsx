import { cn } from "@/lib/utils";

export function Crescent({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 32 32"
      className={cn("size-7", className)}
      aria-hidden="true"
    >
      <circle cx="16" cy="16" r="15" fill="currentColor" opacity="0.08" />
      <path
        d="M19.2 6.4c-6.1.9-10.6 6.4-10.2 12.7.4 5.6 5 10 10.6 10.4-6.8.8-13.2-4.4-13.8-11.5C5.1 10.2 11 4.2 18.6 4c.2.8.5 1.6.6 2.4Z"
        fill="currentColor"
      />
    </svg>
  );
}

export function Wordmark({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-2.5 text-fg">
      <Crescent />
      <div className="leading-none">
        <div className="font-display text-lg font-medium tracking-tight">سهرة</div>
        {!compact ? (
          <div className="mt-0.5 text-[0.65rem] text-subtle">Sahra</div>
        ) : null}
      </div>
    </div>
  );
}
