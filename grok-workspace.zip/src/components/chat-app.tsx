import { Menu, SlidersHorizontal, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { useShallow } from "zustand/react/shallow";
import { Composer } from "@/components/composer";
import { MessageList } from "@/components/messages";
import { PersonaDialog } from "@/components/persona-dialog";
import { Sidebar } from "@/components/sidebar";
import { Button } from "@/components/ui/button";
import { MAX_HISTORY, MAX_MESSAGE_CHARS } from "@/lib/defaults";
import { clearGateToken, emitGateLocked, gateHeaders } from "@/lib/site-gate";
import { selectActive, useSahraStore } from "@/lib/store";
import { readChatStream } from "@/lib/stream";
import type { ChatImage, ChatMessage } from "@/lib/types";
import { snippet, uid } from "@/lib/utils";

export function ChatApp() {
  const sidebarOpen = useSahraStore((s) => s.sidebarOpen);
  const setSidebarOpen = useSahraStore((s) => s.setSidebarOpen);
  const { conversation, persona } = useSahraStore(useShallow(selectActive));
  const streamingId = useSahraStore((s) => s.streamingId);
  const error = useSahraStore((s) => s.error);
  const setError = useSahraStore((s) => s.setError);
  const setMessageContent = useSahraStore((s) => s.setMessageContent);
  const setStreamingId = useSahraStore((s) => s.setStreamingId);
  const applyPersonaToActive = useSahraStore((s) => s.applyPersonaToActive);
  const personas = useSahraStore((s) => s.personas);
  const newConversation = useSahraStore((s) => s.newConversation);

  const [draft, setDraft] = useState("");
  const [pendingImages, setPendingImages] = useState<ChatImage[]>([]);
  const [personaOpen, setPersonaOpen] = useState(false);
  const abortRef = useRef<AbortController | null>(null);

  useEffect(() => {
    void useSahraStore.persist.rehydrate();
  }, []);

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "n") {
        e.preventDefault();
        newConversation();
      }
      if (e.key === "Escape") setSidebarOpen(false);
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [newConversation, setSidebarOpen]);

  useEffect(() => {
    return () => abortRef.current?.abort();
  }, []);

  async function send(text: string, mode: "new" | "regen" = "new", attached: ChatImage[] = []) {
    const state = useSahraStore.getState();
    const active = selectActive(state);
    const conv = active.conversation;
    const p = active.persona;
    if (!conv || !p) return;
    const content = text.trim().slice(0, MAX_MESSAGE_CHARS);
    const images = attached;
    if (!content && !images.length) return;

    let prior = conv.messages;
    if (mode === "regen") {
      if (prior.at(-1)?.role === "assistant") prior = prior.slice(0, -1);
      if (prior.at(-1)?.role === "user") prior = prior.slice(0, -1);
    }

    const userMsg: ChatMessage = {
      id: uid("msg"),
      role: "user",
      content,
      createdAt: Date.now(),
      images: images.length ? images : undefined,
    };
    const assistantMsg: ChatMessage = {
      id: uid("msg"),
      role: "assistant",
      content: "",
      createdAt: Date.now(),
    };

    const titled =
      conv.title === "حوار جديد"
        ? snippet(content || "صورة", 36)
        : conv.title;

    useSahraStore.setState({
      conversations: state.conversations
        .map((c) =>
          c.id === conv.id
            ? {
                ...c,
                title: titled,
                messages: [...prior, userMsg, assistantMsg],
                updatedAt: Date.now(),
              }
            : c,
        )
        .sort((a, b) => b.updatedAt - a.updatedAt),
      streamingId: assistantMsg.id,
      error: null,
    });
    setDraft("");
    if (mode === "new") setPendingImages([]);

    const payloadMessages = [...prior, userMsg]
      .slice(-MAX_HISTORY)
      .map((m) => ({
        role: m.role,
        content: m.content,
        images: m.images?.map((img) => ({ src: img.src })),
      }));

    abortRef.current?.abort();
    const ac = new AbortController();
    abortRef.current = ac;

    let assembled = "";

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json", ...gateHeaders() },
        signal: ac.signal,
        body: JSON.stringify({
          conversationId: conv.id,
          messages: payloadMessages,
          persona: {
            name: p.name,
            role: p.role,
            tone: p.tone,
            style: p.style,
            frankness: p.frankness,
            boundaries: p.boundaries,
            instructions: p.instructions,
            temperature: p.temperature,
          },
        }),
      });

      if (res.status === 401) {
        clearGateToken();
        emitGateLocked();
      }

      await readChatStream(
        res,
        {
          onDelta: (piece) => {
            assembled += piece;
            setMessageContent(conv.id, assistantMsg.id, assembled);
          },
          onDone: () => {
            setStreamingId(null);
            if (!assembled.trim()) {
              setMessageContent(
                conv.id,
                assistantMsg.id,
                "لم يصل رد. أعد المحاولة.",
              );
            }
          },
          onError: (message) => {
            setStreamingId(null);
            setError(message);
            if (!assembled) {
              setMessageContent(conv.id, assistantMsg.id, "");
            }
          },
        },
        ac.signal,
      );
    } catch (err) {
      if (ac.signal.aborted) {
        setStreamingId(null);
        return;
      }
      setStreamingId(null);
      setError(err instanceof Error ? err.message : "تعذّر الإرسال.");
    }
  }

  function stop() {
    abortRef.current?.abort();
    setStreamingId(null);
  }

  function regenerate() {
    const lastUser = [...(conversation?.messages ?? [])]
      .reverse()
      .find((m) => m.role === "user");
    if (!lastUser) return;
    void send(lastUser.content, "regen", lastUser.images ?? []);
  }

  const streaming = streamingId !== null;

  return (
    <div className="flex h-dvh overflow-hidden bg-bg text-fg">
      <aside className="hidden w-[18.5rem] shrink-0 border-e border-border md:block">
        <Sidebar onOpenPersonas={() => { setPersonaOpen(true); setSidebarOpen(false); }} />
      </aside>

      {sidebarOpen ? (
        <div className="fixed inset-0 z-40 md:hidden">
          <button
            type="button"
            className="absolute inset-0 bg-bg/70"
            aria-label="إغلاق القائمة"
            onClick={() => setSidebarOpen(false)}
          />
          <div className="absolute inset-y-0 start-0 w-[min(100%,18.5rem)] shadow-[var(--shadow-float)]">
            <Sidebar onOpenPersonas={() => { setPersonaOpen(true); setSidebarOpen(false); }} />
          </div>
        </div>
      ) : null}

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex h-14 shrink-0 items-center gap-2 border-b border-border px-2 sm:px-3">
          <Button
            variant="ghost"
            size="icon-sm"
            className="md:hidden"
            onClick={() => setSidebarOpen(!sidebarOpen)}
            aria-label="الجلسات"
          >
            {sidebarOpen ? <X className="size-4" /> : <Menu className="size-4" />}
          </Button>
          <div className="min-w-0 flex-1">
            <div className="truncate text-sm font-medium">
              {conversation?.title ?? "سهرة"}
            </div>
            <div className="truncate text-[0.7rem] text-subtle">
              {persona?.tagline}
            </div>
          </div>
          <div className="flex items-center gap-1">
            <label className="sr-only" htmlFor="persona-select">
              الشخصية
            </label>
            <select
              id="persona-select"
              value={persona?.id ?? ""}
              onChange={(e) => applyPersonaToActive(e.target.value)}
              className="h-9 max-w-36 rounded-lg bg-transparent px-2 text-sm text-fg outline-none hover:bg-elevated"
            >
              {personas.map((p) => (
                <option key={p.id} value={p.id} className="bg-surface text-fg">
                  {p.name}
                </option>
              ))}
            </select>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setPersonaOpen(true)}
              aria-label="تعديل الشخصية"
            >
              <SlidersHorizontal className="size-3.5" />
              <span className="hidden sm:inline">تعديل</span>
            </Button>
          </div>
        </header>

        <MessageList
          messages={conversation?.messages ?? []}
          streamingId={streamingId}
          persona={persona}
          error={error}
          onPickStarter={(text) => {
            void send(text, "new", []);
          }}
          onRegenerate={regenerate}
        />

        <Composer
          value={draft}
          onChange={setDraft}
          images={pendingImages}
          onImages={setPendingImages}
          onSubmit={({ text, images }) => void send(text, "new", images)}
          onStop={stop}
          disabled={!conversation || !persona}
          streaming={streaming}
          placeholder={
            persona
              ? `اكتب إلى ${persona.name} أو أرفق صورة…`
              : "اكتب رسالتك أو أرفق صورة…"
          }
        />
      </div>

      <PersonaDialog open={personaOpen} onOpenChange={setPersonaOpen} />
    </div>
  );
}
