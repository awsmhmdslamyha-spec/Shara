import { Lock, MessageSquarePlus, Pencil, Search, Trash2 } from "lucide-react";
import { useMemo, useState } from "react";
import { useShallow } from "zustand/react/shallow";
import { Wordmark } from "@/components/logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { FRANKNESS_LABEL } from "@/lib/defaults";
import { lockSite } from "@/lib/site-gate";
import { selectActive, useSahraStore } from "@/lib/store";
import { cn, formatRelative, groupDay } from "@/lib/utils";

const DAY_LABEL = {
  today: "اليوم",
  yesterday: "أمس",
  week: "هذا الأسبوع",
  older: "أقدم",
} as const;

export function Sidebar({
  onOpenPersonas,
}: {
  onOpenPersonas: () => void;
}) {
  const conversations = useSahraStore((s) => s.conversations);
  const personas = useSahraStore((s) => s.personas);
  const { conversation: active, persona } = useSahraStore(useShallow(selectActive));
  const newConversation = useSahraStore((s) => s.newConversation);
  const setActiveConversation = useSahraStore((s) => s.setActiveConversation);
  const deleteConversation = useSahraStore((s) => s.deleteConversation);
  const renameConversation = useSahraStore((s) => s.renameConversation);
  const [query, setQuery] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draft, setDraft] = useState("");

  const filtered = useMemo(() => {
    const q = query.trim();
    const list = q
      ? conversations.filter((c) => {
          const personaName =
            personas.find((p) => p.id === c.personaId)?.name ?? "";
          return (
            c.title.includes(q) ||
            personaName.includes(q) ||
            c.messages.some((m) => m.content.includes(q))
          );
        })
      : conversations;
    const groups: { key: keyof typeof DAY_LABEL; items: typeof list }[] = [
      { key: "today", items: [] },
      { key: "yesterday", items: [] },
      { key: "week", items: [] },
      { key: "older", items: [] },
    ];
    for (const c of list) {
      const g = groups.find((x) => x.key === groupDay(c.updatedAt));
      g?.items.push(c);
    }
    return groups.filter((g) => g.items.length);
  }, [conversations, personas, query]);

  return (
    <div className="flex h-full flex-col bg-surface">
      <div className="flex items-center justify-between px-4 pt-5 pb-3">
        <Wordmark />
      </div>

      <div className="px-3">
        <Button
          className="w-full justify-between"
          onClick={() => newConversation()}
        >
          <span>حوار جديد</span>
          <MessageSquarePlus className="size-4" />
        </Button>
        <div className="relative mt-3">
          <Search className="pointer-events-none absolute top-1/2 start-3 size-4 -translate-y-1/2 text-subtle" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="ابحث في الجلسات"
            className="ps-9"
            aria-label="بحث"
          />
        </div>
      </div>

      <nav className="mt-3 min-h-0 flex-1 overflow-y-auto px-2 pb-3 scrollbar-thin">
        {filtered.length === 0 ? (
          <p className="px-3 py-8 text-center text-sm text-subtle">لا جلسات مطابقة</p>
        ) : (
          filtered.map((group) => (
            <div key={group.key} className="mb-4">
              <div className="px-3 pb-1.5 text-[0.7rem] font-medium tracking-wide text-subtle">
                {DAY_LABEL[group.key]}
              </div>
              <ul className="space-y-0.5">
                {group.items.map((c) => {
                  const p = personas.find((x) => x.id === c.personaId);
                  const isActive = c.id === active?.id;
                  return (
                    <li key={c.id}>
                      <div
                        className={cn(
                          "group flex items-start gap-1 rounded-xl px-2 py-2",
                          isActive ? "bg-elevated" : "hover:bg-elevated/60",
                        )}
                      >
                        <button
                          type="button"
                          onClick={() => setActiveConversation(c.id)}
                          className="min-w-0 flex-1 text-start"
                        >
                          {editingId === c.id ? (
                            <input
                              autoFocus
                              value={draft}
                              onChange={(e) => setDraft(e.target.value)}
                              onClick={(e) => e.stopPropagation()}
                              onBlur={() => {
                                renameConversation(c.id, draft);
                                setEditingId(null);
                              }}
                              onKeyDown={(e) => {
                                if (e.key === "Enter") {
                                  renameConversation(c.id, draft);
                                  setEditingId(null);
                                }
                                if (e.key === "Escape") setEditingId(null);
                              }}
                              className="h-8 w-full rounded-lg bg-bg px-2 text-sm outline-none"
                            />
                          ) : (
                            <>
                              <div className="truncate text-sm font-medium">
                                {c.title}
                              </div>
                              <div className="mt-0.5 flex items-center gap-2 text-[0.7rem] text-subtle">
                                <span className="truncate">{p?.name ?? "سهرة"}</span>
                                <span className="tabular-nums">
                                  {formatRelative(c.updatedAt)}
                                </span>
                              </div>
                            </>
                          )}
                        </button>
                        <div className="flex shrink-0 opacity-0 transition-opacity group-hover:opacity-100 group-focus-within:opacity-100 max-md:opacity-100">
                          <button
                            type="button"
                            className="inline-flex size-8 items-center justify-center rounded-lg text-subtle hover:bg-bg hover:text-fg"
                            aria-label="إعادة تسمية"
                            onClick={() => {
                              setEditingId(c.id);
                              setDraft(c.title);
                            }}
                          >
                            <Pencil className="size-3.5" />
                          </button>
                          <button
                            type="button"
                            className="inline-flex size-8 items-center justify-center rounded-lg text-subtle hover:bg-bg hover:text-danger"
                            aria-label="حذف الجلسة"
                            onClick={() => deleteConversation(c.id)}
                          >
                            <Trash2 className="size-3.5" />
                          </button>
                        </div>
                      </div>
                    </li>
                  );
                })}
              </ul>
            </div>
          ))
        )}
      </nav>

      <div className="border-t border-border p-3">
        <button
          type="button"
          onClick={onOpenPersonas}
          className="flex w-full items-center justify-between rounded-xl bg-elevated px-3 py-2.5 text-start hover:shadow-[var(--shadow-border-hover)]"
        >
          <div className="min-w-0">
            <div className="text-[0.7rem] text-subtle">الشخصية النشطة</div>
            <div className="truncate text-sm font-medium">{persona?.name ?? "سهرة"}</div>
          </div>
          {persona ? (
            <span className="shrink-0 rounded-full bg-bg px-2 py-1 text-[0.65rem] text-muted">
              {FRANKNESS_LABEL[persona.frankness]}
            </span>
          ) : null}
        </button>
        <button
          type="button"
          onClick={() => void lockSite()}
          className="mt-2 flex w-full items-center justify-center gap-2 rounded-xl px-3 py-2 text-sm text-subtle hover:bg-elevated hover:text-fg"
        >
          <Lock className="size-3.5" />
          قفل سهرة
        </button>
      </div>
    </div>
  );
}
