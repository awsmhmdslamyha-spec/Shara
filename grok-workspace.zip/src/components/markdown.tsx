import Markdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { cn, isMostlyArabic } from "@/lib/utils";

export function MessageMarkdown({ content }: { content: string }) {
  const dir = isMostlyArabic(content) ? "rtl" : "ltr";
  return (
    <div
      dir={dir}
      className={cn(
        "max-w-none text-[0.98rem] leading-[1.75] text-fg",
        "[&_p]:mb-3 [&_p:last-child]:mb-0",
        "[&_h1]:mb-3 [&_h1]:text-xl [&_h1]:font-medium",
        "[&_h2]:mb-2.5 [&_h2]:text-lg [&_h2]:font-medium",
        "[&_h3]:mb-2 [&_h3]:text-base [&_h3]:font-medium",
        "[&_ul]:mb-3 [&_ul]:list-disc [&_ul]:ps-5",
        "[&_ol]:mb-3 [&_ol]:list-decimal [&_ol]:ps-5",
        "[&_li]:mb-1",
        "[&_blockquote]:mb-3 [&_blockquote]:border-s-2 [&_blockquote]:border-border-strong [&_blockquote]:ps-3 [&_blockquote]:text-muted",
        "[&_a]:text-accent [&_a]:underline [&_a]:underline-offset-4",
        "[&_hr]:my-5 [&_hr]:border-border",
        "[&_code]:rounded-md [&_code]:bg-elevated [&_code]:px-1.5 [&_code]:py-0.5 [&_code]:font-mono [&_code]:text-[0.85em]",
        "[&_pre]:mb-3 [&_pre]:overflow-x-auto [&_pre]:rounded-xl [&_pre]:bg-elevated [&_pre]:p-3 [&_pre]:shadow-[var(--shadow-border)]",
        "[&_pre_code]:bg-transparent [&_pre_code]:p-0",
        "[&_strong]:font-medium",
      )}
    >
      <Markdown
        remarkPlugins={[remarkGfm]}
        components={{
          a: ({ href, children }) => (
            <a href={href} target="_blank" rel="noreferrer noopener">
              {children}
            </a>
          ),
        }}
      >
        {content}
      </Markdown>
    </div>
  );
}
