import { ArrowUp, ImagePlus, LoaderCircle, Square, X } from "lucide-react";
import {
  useEffect,
  useRef,
  useState,
  type ClipboardEvent,
  type DragEvent,
  type FormEvent,
  type KeyboardEvent,
} from "react";
import { MAX_MESSAGE_CHARS } from "@/lib/defaults";
import { filesToChatImages, MAX_IMAGES_PER_MESSAGE } from "@/lib/images";
import type { ChatImage } from "@/lib/types";
import { cn, isMostlyArabic } from "@/lib/utils";

export function Composer({
  value,
  onChange,
  images,
  onImages,
  onSubmit,
  onStop,
  disabled,
  streaming,
  placeholder,
}: {
  value: string;
  onChange: (v: string) => void;
  images: ChatImage[];
  onImages: (next: ChatImage[] | ((prev: ChatImage[]) => ChatImage[])) => void;
  onSubmit: (payload: { text: string; images: ChatImage[] }) => void;
  onStop: () => void;
  disabled: boolean;
  streaming: boolean;
  placeholder: string;
}) {
  const ref = useRef<HTMLTextAreaElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const [dragOver, setDragOver] = useState(false);
  const [busy, setBusy] = useState(false);
  const [attachError, setAttachError] = useState<string | null>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = `${Math.min(el.scrollHeight, 200)}px`;
  }, [value]);

  const canSend = Boolean(value.trim() || images.length) && !busy;

  function submit() {
    if (streaming || !canSend || disabled) return;
    setAttachError(null);
    onSubmit({ text: value, images });
  }

  function handleKey(e: KeyboardEvent<HTMLTextAreaElement>) {
    if (e.nativeEvent.isComposing) return;
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      submit();
    }
  }

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (streaming) {
      onStop();
      return;
    }
    submit();
  }

  function takeFiles(list: File[] | FileList | null) {
    if (!list || disabled || streaming || busy) return;
    const files = Array.from(list).filter((f) => {
      if (f.size < 32) return false;
      if (!f.type) return /\.(jpe?g|png|webp|gif|heic|heif)$/i.test(f.name) || f.size > 32;
      return f.type.startsWith("image/");
    });
    if (!files.length) return;
    setBusy(true);
    setAttachError(null);
    void (async () => {
      try {
        const { images: added, error } = await filesToChatImages(files, images.length);
        if (added.length) {
          onImages((prev) => [...prev, ...added].slice(0, MAX_IMAGES_PER_MESSAGE));
        }
        if (error) setAttachError(error);
      } catch {
        setAttachError("ما قدرت أرفق هذي الصورة. جرّب صورة ثانية.");
      } finally {
        setBusy(false);
      }
    })();
  }

  function onPaste(e: ClipboardEvent<HTMLTextAreaElement>) {
    const text = e.clipboardData.getData("text/plain") || e.clipboardData.getData("text");
    if (text.trim()) return;

    const fromFiles = Array.from(e.clipboardData.files || []).filter((f) =>
      f.type.startsWith("image/"),
    );
    const fromItems = Array.from(e.clipboardData.items || [])
      .filter((item) => item.type.startsWith("image/"))
      .map((item) => item.getAsFile())
      .filter((f): f is File => f != null && f.size > 32);
    const files = fromFiles.length ? fromFiles : fromItems;
    if (!files.length) return;
    e.preventDefault();
    takeFiles(files);
  }

  function onDrop(e: DragEvent) {
    e.preventDefault();
    setDragOver(false);
    takeFiles(e.dataTransfer.files);
  }

  const dir = isMostlyArabic(value) || !value.trim() ? "rtl" : "ltr";
  const over = value.length > MAX_MESSAGE_CHARS;

  return (
    <form onSubmit={handleSubmit} className="mx-auto w-full max-w-3xl px-3 pb-4 pt-2 sm:px-4">
      <div
        onDragEnter={(e) => {
          e.preventDefault();
          if (!streaming) setDragOver(true);
        }}
        onDragOver={(e) => {
          e.preventDefault();
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={onDrop}
        className={cn(
          "rounded-2xl bg-elevated p-2 shadow-[var(--shadow-border)]",
          "focus-within:shadow-[var(--shadow-border-hover)]",
          dragOver && "shadow-[var(--shadow-border-hover)] ring-1 ring-accent/40",
        )}
      >
        {images.length ? (
          <div className="flex gap-2 overflow-x-auto px-2 pb-2 pt-1 scrollbar-thin">
            {images.map((img) => (
              <div key={img.id} className="relative shrink-0">
                <img
                  src={img.src}
                  alt=""
                  className="h-16 w-16 rounded-xl object-cover shadow-[var(--shadow-border)]"
                />
                <button
                  type="button"
                  className="absolute -top-1 -start-1 inline-flex size-5 items-center justify-center rounded-full bg-fg text-bg"
                  aria-label="إزالة الصورة"
                  onClick={() => onImages((prev) => prev.filter((x) => x.id !== img.id))}
                >
                  <X className="size-3" />
                </button>
              </div>
            ))}
          </div>
        ) : null}
        <div className="flex items-end gap-2 ps-2">
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            className="sr-only"
            onChange={(e) => {
              const selected = e.target.files ? Array.from(e.target.files) : [];
              e.target.value = "";
              takeFiles(selected);
            }}
          />
          <button
            type="button"
            disabled={disabled || streaming || busy || images.length >= MAX_IMAGES_PER_MESSAGE}
            onClick={() => fileRef.current?.click()}
            className="mb-0.5 inline-flex size-11 shrink-0 items-center justify-center rounded-xl text-muted hover:bg-bg hover:text-fg disabled:opacity-30"
            aria-label="إرفاق صورة"
          >
            {busy ? (
              <LoaderCircle className="size-5 animate-spin" />
            ) : (
              <ImagePlus className="size-5" />
            )}
          </button>
          <textarea
            ref={ref}
            dir={dir}
            rows={1}
            value={value}
            onChange={(e) => {
              onChange(e.target.value);
              if (attachError) setAttachError(null);
            }}
            onKeyDown={handleKey}
            onPaste={onPaste}
            placeholder={placeholder}
            disabled={disabled && !streaming}
            className="max-h-52 min-h-11 flex-1 resize-none bg-transparent py-2.5 text-[0.98rem] leading-relaxed text-fg outline-none placeholder:text-subtle disabled:opacity-60"
          />
          <button
            type="submit"
            disabled={!streaming && (!canSend || disabled || over)}
            className={cn(
              "mb-0.5 inline-flex size-11 shrink-0 items-center justify-center rounded-xl transition-transform duration-150 active:enabled:scale-[0.96]",
              streaming
                ? "bg-fg text-bg"
                : "bg-accent text-accent-fg disabled:opacity-30",
            )}
            aria-label={streaming ? "إيقاف" : "إرسال"}
          >
            {streaming ? <Square className="size-3.5 fill-current" /> : <ArrowUp className="size-5" />}
          </button>
        </div>
      </div>
      <div className="mt-2 flex items-center justify-between gap-3 px-1 text-[0.7rem] text-subtle">
        <span>
          {attachError ? (
            <span className="text-danger">{attachError}</span>
          ) : busy ? (
            "جاري تجهيز الصورة…"
          ) : (
            <span className="hidden sm:inline">صورة واحدة تكفي · يمكنك إضافة المزيد لاحقاً</span>
          )}
        </span>
        {over ? (
          <span className="text-danger">تجاوزت حد الرسالة</span>
        ) : (
          <span className="tabular-nums">
            {value.length ? `${value.length} / ${MAX_MESSAGE_CHARS}` : ""}
          </span>
        )}
      </div>
    </form>
  );
}
