import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function uid(prefix = "id"): string {
  if (typeof crypto !== "undefined" && crypto.randomUUID) {
    return `${prefix}_${crypto.randomUUID()}`;
  }
  return `${prefix}_${Math.random().toString(36).slice(2, 10)}${Date.now().toString(36)}`;
}

export function clamp(n: number, min: number, max: number) {
  return Math.min(max, Math.max(min, n));
}

export function isMostlyArabic(text: string): boolean {
  const letters = text.replace(/[^\p{L}]/gu, "");
  if (!letters) return true;
  const arabic = (letters.match(/\p{Script=Arabic}/gu) ?? []).length;
  return arabic / letters.length >= 0.4;
}

export function snippet(text: string, max = 42): string {
  const clean = text.replace(/\s+/g, " ").trim();
  if (clean.length <= max) return clean;
  return `${clean.slice(0, max).trimEnd()}…`;
}

function effectiveTime(ts: number): number {
  return ts < 1_000_000 ? Date.now() : ts;
}

export function formatRelative(ts: number): string {
  const diff = Date.now() - effectiveTime(ts);
  const min = Math.round(diff / 60000);
  if (min < 1) return "الآن";
  if (min < 60) return `قبل ${min} د`;
  const hrs = Math.round(min / 60);
  if (hrs < 24) return `قبل ${hrs} س`;
  const days = Math.round(hrs / 24);
  if (days === 1) return "أمس";
  if (days < 7) return `قبل ${days} أيام`;
  return new Date(ts).toLocaleDateString("ar", {
    day: "numeric",
    month: "short",
  });
}

export function groupDay(ts: number): "today" | "yesterday" | "week" | "older" {
  const d = new Date(effectiveTime(ts));
  const now = new Date();
  const start = (x: Date) =>
    new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
  const delta = start(now) - start(d);
  if (delta === 0) return "today";
  if (delta === 86400000) return "yesterday";
  if (delta < 7 * 86400000) return "week";
  return "older";
}
