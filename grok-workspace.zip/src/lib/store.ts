import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import { blankPersona, defaultPersonas } from "./defaults";
import type { ChatMessage, Conversation, Persona } from "./types";
import { snippet, uid } from "./utils";

type SahraState = {
  hydrated: boolean;
  conversations: Conversation[];
  personas: Persona[];
  activeConversationId: string | null;
  activePersonaId: string | null;
  sidebarOpen: boolean;
  streamingId: string | null;
  error: string | null;

  hydrateDefaults: () => void;
  setSidebarOpen: (open: boolean) => void;
  setError: (error: string | null) => void;

  newConversation: (personaId?: string) => string;
  setActiveConversation: (id: string) => void;
  renameConversation: (id: string, title: string) => void;
  deleteConversation: (id: string) => void;
  touchConversation: (id: string) => void;

  setActivePersona: (id: string) => void;
  applyPersonaToActive: (id: string) => void;
  upsertPersona: (persona: Persona) => void;
  createPersona: () => string;
  duplicatePersona: (id: string) => string;
  deletePersona: (id: string) => void;

  appendMessage: (conversationId: string, message: ChatMessage) => void;
  setMessageContent: (
    conversationId: string,
    messageId: string,
    content: string,
  ) => void;
  removeMessagesAfter: (conversationId: string, messageId: string) => void;
  setStreamingId: (id: string | null) => void;
};

function seed(): Pick<
  SahraState,
  "conversations" | "personas" | "activeConversationId" | "activePersonaId"
> {
  const personas = defaultPersonas();
  const personaId = personas[0]!.id;
  const conv: Conversation = {
    id: "conv-welcome",
    title: "حوار جديد",
    personaId,
    messages: [],
    createdAt: 1,
    updatedAt: 1,
  };
  return {
    personas,
    conversations: [conv],
    activeConversationId: conv.id,
    activePersonaId: personaId,
  };
}

function stripOldImages(conversations: Conversation[]): Conversation[] {
  return conversations.map((c) => {
    const keepFrom = Math.max(0, c.messages.length - 20);
    return {
      ...c,
      messages: c.messages.map((m, i) =>
        i >= keepFrom || !m.images?.length ? m : { ...m, images: undefined },
      ),
    };
  });
}

const persistStorage = createJSONStorage(() => ({
  getItem: (key) => localStorage.getItem(key),
  setItem: (key, value) => {
    try {
      localStorage.setItem(key, value);
    } catch {
      try {
        const parsed = JSON.parse(value) as {
          state?: { conversations?: Conversation[] };
        };
        if (parsed.state?.conversations) {
          parsed.state.conversations = stripOldImages(parsed.state.conversations);
        }
        localStorage.setItem(key, JSON.stringify(parsed));
      } catch {
        /* quota still exhausted */
      }
    }
  },
  removeItem: (key) => localStorage.removeItem(key),
}));

export const useSahraStore = create<SahraState>()(
  persist(
    (set, get) => ({
      hydrated: false,
      ...seed(),
      sidebarOpen: false,
      streamingId: null,
      error: null,

      hydrateDefaults: () => {
        const s = get();
        const patch: Partial<SahraState> = { hydrated: true };
        if (!s.personas.length) {
          const seeded = seed();
          Object.assign(patch, seeded);
        } else if (!s.conversations.length) {
          const personaId = s.activePersonaId ?? s.personas[0]!.id;
          const conv: Conversation = {
            id: uid("conv"),
            title: "حوار جديد",
            personaId,
            messages: [],
            createdAt: Date.now(),
            updatedAt: Date.now(),
          };
          patch.conversations = [conv];
          patch.activeConversationId = conv.id;
          patch.activePersonaId = personaId;
        }
        set(patch);
      },

      setSidebarOpen: (open) => set({ sidebarOpen: open }),
      setError: (error) => set({ error }),

      newConversation: (personaId) => {
        const s = get();
        const pid =
          personaId ?? s.activePersonaId ?? s.personas[0]?.id ?? seed().activePersonaId!;
        const conv: Conversation = {
          id: uid("conv"),
          title: "حوار جديد",
          personaId: pid,
          messages: [],
          createdAt: Date.now(),
          updatedAt: Date.now(),
        };
        set({
          conversations: [conv, ...s.conversations],
          activeConversationId: conv.id,
          activePersonaId: pid,
          sidebarOpen: false,
          error: null,
        });
        return conv.id;
      },

      setActiveConversation: (id) => {
        const conv = get().conversations.find((c) => c.id === id);
        if (!conv) return;
        set({
          activeConversationId: id,
          activePersonaId: conv.personaId,
          sidebarOpen: false,
          error: null,
        });
      },

      renameConversation: (id, title) => {
        const t = title.trim() || "حوار بلا عنوان";
        set({
          conversations: get().conversations.map((c) =>
            c.id === id ? { ...c, title: t, updatedAt: Date.now() } : c,
          ),
        });
      },

      deleteConversation: (id) => {
        const s = get();
        const rest = s.conversations.filter((c) => c.id !== id);
        if (!rest.length) {
          const pid = s.activePersonaId ?? s.personas[0]?.id ?? seed().activePersonaId!;
          const conv: Conversation = {
            id: uid("conv"),
            title: "حوار جديد",
            personaId: pid,
            messages: [],
            createdAt: Date.now(),
            updatedAt: Date.now(),
          };
          set({
            conversations: [conv],
            activeConversationId: conv.id,
            activePersonaId: pid,
          });
          return;
        }
        const keeping =
          s.activeConversationId === id
            ? rest[0]!
            : (rest.find((c) => c.id === s.activeConversationId) ?? rest[0]!);
        set({
          conversations: rest,
          activeConversationId: keeping.id,
          activePersonaId: keeping.personaId,
        });
      },

      touchConversation: (id) => {
        set({
          conversations: get()
            .conversations.map((c) =>
              c.id === id ? { ...c, updatedAt: Date.now() } : c,
            )
            .sort((a, b) => b.updatedAt - a.updatedAt),
        });
      },

      setActivePersona: (id) => set({ activePersonaId: id }),

      applyPersonaToActive: (id) => {
        const cid = get().activeConversationId;
        set({
          activePersonaId: id,
          conversations: get().conversations.map((c) =>
            c.id === cid ? { ...c, personaId: id, updatedAt: Date.now() } : c,
          ),
        });
      },

      upsertPersona: (persona) => {
        const list = get().personas;
        const exists = list.some((p) => p.id === persona.id);
        set({
          personas: exists
            ? list.map((p) => (p.id === persona.id ? persona : p))
            : [persona, ...list],
          activePersonaId: persona.id,
        });
        const cid = get().activeConversationId;
        if (cid) {
          set({
            conversations: get().conversations.map((c) =>
              c.id === cid
                ? { ...c, personaId: persona.id, updatedAt: Date.now() }
                : c,
            ),
          });
        }
      },

      createPersona: () => {
        const now = Date.now();
        const persona: Persona = {
          ...blankPersona(),
          id: uid("persona"),
          createdAt: now,
          updatedAt: now,
        };
        set({ personas: [persona, ...get().personas], activePersonaId: persona.id });
        return persona.id;
      },

      duplicatePersona: (id) => {
        const src = get().personas.find((p) => p.id === id);
        if (!src) return id;
        const now = Date.now();
        const copy: Persona = {
          ...src,
          id: uid("persona"),
          name: `${src.name} — نسخة`,
          createdAt: now,
          updatedAt: now,
        };
        set({ personas: [copy, ...get().personas], activePersonaId: copy.id });
        return copy.id;
      },

      deletePersona: (id) => {
        const rest = get().personas.filter((p) => p.id !== id);
        if (!rest.length) return;
        const nextId =
          get().activePersonaId === id ? rest[0]!.id : get().activePersonaId;
        set({
          personas: rest,
          activePersonaId: nextId,
          conversations: get().conversations.map((c) =>
            c.personaId === id ? { ...c, personaId: rest[0]!.id } : c,
          ),
        });
      },

      appendMessage: (conversationId, message) => {
        set({
          conversations: get()
            .conversations.map((c) => {
              if (c.id !== conversationId) return c;
              const titled =
                c.title === "حوار جديد" && message.role === "user"
                  ? snippet(message.content || "صورة", 36)
                  : c.title;
              return {
                ...c,
                title: titled,
                messages: [...c.messages, message],
                updatedAt: Date.now(),
              };
            })
            .sort((a, b) => b.updatedAt - a.updatedAt),
        });
      },

      setMessageContent: (conversationId, messageId, content) => {
        set({
          conversations: get().conversations.map((c) =>
            c.id !== conversationId
              ? c
              : {
                  ...c,
                  messages: c.messages.map((m) =>
                    m.id === messageId ? { ...m, content } : m,
                  ),
                  updatedAt: Date.now(),
                },
          ),
        });
      },

      removeMessagesAfter: (conversationId, messageId) => {
        set({
          conversations: get().conversations.map((c) => {
            if (c.id !== conversationId) return c;
            const idx = c.messages.findIndex((m) => m.id === messageId);
            if (idx < 0) return c;
            return {
              ...c,
              messages: c.messages.slice(0, idx + 1),
              updatedAt: Date.now(),
            };
          }),
        });
      },

      setStreamingId: (id) => set({ streamingId: id }),
    }),
    {
      name: "sahra-v1",
      skipHydration: true,
      storage: persistStorage,
      partialize: (s) => ({
        conversations: s.conversations,
        personas: s.personas,
        activeConversationId: s.activeConversationId,
        activePersonaId: s.activePersonaId,
      }),
      onRehydrateStorage: () => () => {
        useSahraStore.getState().hydrateDefaults();
      },
    },
  ),
);

export function selectActive(s: SahraState) {
  const conversation =
    s.conversations.find((c) => c.id === s.activeConversationId) ??
    s.conversations[0] ??
    null;
  const persona =
    s.personas.find((p) => p.id === (conversation?.personaId ?? s.activePersonaId)) ??
    s.personas[0] ??
    null;
  return { conversation, persona };
}
