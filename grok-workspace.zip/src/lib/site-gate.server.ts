import { createHash, timingSafeEqual } from "node:crypto";
import { jwtVerify, SignJWT } from "jose";

const COOKIE = "sahra_gate";
const ISS = "sahra";
const AUD = "gate";
const TOKEN_TTL_SEC = 60 * 60 * 12;
const MAX_PASSWORD_CHARS = 128;
const MAX_FAILS = 8;
const LOCKOUT_MS = 10 * 60 * 1000;
const FAIL_DELAY_MS = 280;

/**
 * SHA-256 of the default access password. Override at runtime with
 * SAHRA_ACCESS_PASSWORD (plaintext, never shipped to the client).
 * Do not store plaintext in this file.
 */
const BAKED_PASSWORD_SHA256 =
  "f34da4fc07d95081b53844e6e6f2b93a9740e3afdd070b9a2e79e8bc676af1e1";

type Bucket = { fails: number; lockedUntil: number };
const attempts = new Map<string, Bucket>();

function sha256(value: string): Buffer {
  return createHash("sha256").update(value, "utf8").digest();
}

function configuredPasswordHash(): Buffer {
  const env = process.env.SAHRA_ACCESS_PASSWORD;
  if (typeof env === "string" && env.trim().length >= 4) {
    return sha256(env.trim().normalize("NFC"));
  }
  return Buffer.from(BAKED_PASSWORD_SHA256, "hex");
}

function jwtSecret(): Uint8Array {
  return sha256(`sahra-gate-v2:${configuredPasswordHash().toString("hex")}`);
}

function equalHash(a: Buffer, b: Buffer): boolean {
  if (a.length !== 32 || b.length !== 32) return false;
  return timingSafeEqual(a, b);
}

function clientKey(request: Request): string {
  const forwarded = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim();
  const real = request.headers.get("x-real-ip")?.trim();
  const ip = forwarded || real || "unknown";
  return sha256(ip).toString("hex").slice(0, 24);
}

function readBucket(key: string): Bucket {
  const now = Date.now();
  const current = attempts.get(key);
  if (!current) return { fails: 0, lockedUntil: 0 };
  if (current.lockedUntil && current.lockedUntil < now) {
    attempts.delete(key);
    return { fails: 0, lockedUntil: 0 };
  }
  return current;
}

function isHttps(request: Request): boolean {
  if (request.headers.get("x-forwarded-proto") === "https") return true;
  try {
    return new URL(request.url).protocol === "https:";
  } catch {
    return false;
  }
}

export function gateCookieHeader(token: string, request: Request): string {
  const secure = isHttps(request) ? "; Secure" : "";
  return `${COOKIE}=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax${secure}`;
}

export function clearGateCookieHeader(request: Request): string {
  const secure = isHttps(request) ? "; Secure" : "";
  return `${COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${secure}`;
}

export function readGateToken(request: Request): string | null {
  const auth = request.headers.get("authorization");
  if (auth && auth.slice(0, 7).toLowerCase() === "bearer ") {
    const token = auth.slice(7).trim();
    if (token) return token;
  }
  const raw = request.headers.get("cookie") ?? "";
  for (const part of raw.split(";")) {
    const [name, ...rest] = part.trim().split("=");
    if (name === COOKIE) {
      const value = rest.join("=").trim();
      if (value) return decodeURIComponent(value);
    }
  }
  return null;
}

export async function mintGateToken(): Promise<string> {
  return new SignJWT({ role: "owner" })
    .setProtectedHeader({ alg: "HS256", typ: "JWT" })
    .setIssuer(ISS)
    .setAudience(AUD)
    .setIssuedAt()
    .setExpirationTime(`${TOKEN_TTL_SEC}s`)
    .sign(jwtSecret());
}

export async function verifyGateToken(token: string | null): Promise<boolean> {
  if (!token || token.length > 4096) return false;
  try {
    await jwtVerify(token, jwtSecret(), { issuer: ISS, audience: AUD });
    return true;
  } catch {
    return false;
  }
}

export function gateLockout(request: Request): { locked: boolean; retryAfterSec: number } {
  const bucket = readBucket(clientKey(request));
  const wait = bucket.lockedUntil - Date.now();
  if (wait > 0) {
    return { locked: true, retryAfterSec: Math.ceil(wait / 1000) };
  }
  return { locked: false, retryAfterSec: 0 };
}

export async function verifyPasswordAttempt(
  request: Request,
  password: unknown,
): Promise<{ ok: true; token: string } | { ok: false; status: 401 | 429; retryAfterSec?: number }> {
  const lock = gateLockout(request);
  if (lock.locked) {
    return { ok: false, status: 429, retryAfterSec: lock.retryAfterSec };
  }

  const key = clientKey(request);
  const text =
    typeof password === "string" ? password.normalize("NFC").slice(0, MAX_PASSWORD_CHARS) : "";

  await new Promise((r) => setTimeout(r, FAIL_DELAY_MS));

  const ok = text.length >= 4 && equalHash(sha256(text), configuredPasswordHash());
  if (!ok) {
    const bucket = readBucket(key);
    const fails = bucket.fails + 1;
    const lockedUntil = fails >= MAX_FAILS ? Date.now() + LOCKOUT_MS : 0;
    attempts.set(key, { fails, lockedUntil });
    if (lockedUntil) {
      return { ok: false, status: 429, retryAfterSec: Math.ceil(LOCKOUT_MS / 1000) };
    }
    return { ok: false, status: 401 };
  }

  attempts.delete(key);
  return { ok: true, token: await mintGateToken() };
}

export async function requireGate(request: Request): Promise<Response | null> {
  const ok = await verifyGateToken(readGateToken(request));
  if (ok) return null;
  return Response.json(
    { error: "المساحة مقفلة. أدخل كلمة السر أولاً." },
    { status: 401, headers: { "Cache-Control": "no-store" } },
  );
}
