export type Role = "user" | "assistant";

export type Frankness = 1 | 2 | 3 | 4 | 5;

export type ChatImage = {
  id: string;
  src: string;
};

export type ChatMessage = {
  id: string;
  role: Role;
  content: string;
  createdAt: number;
  images?: ChatImage[];
};

export type Persona = {
  id: string;
  name: string;
  tagline: string;
  role: string;
  tone: string;
  style: string;
  frankness: Frankness;
  boundaries: string;
  instructions: string;
  temperature: number;
  createdAt: number;
  updatedAt: number;
};

export type Conversation = {
  id: string;
  title: string;
  personaId: string;
  messages: ChatMessage[];
  createdAt: number;
  updatedAt: number;
};

export type PersonaPayload = Pick<
  Persona,
  | "name"
  | "role"
  | "tone"
  | "style"
  | "frankness"
  | "boundaries"
  | "instructions"
  | "temperature"
>;
