export type StreamHandlers = {
  onDelta: (text: string) => void;
  onDone: () => void;
  onError: (message: string) => void;
};

export async function readChatStream(
  res: Response,
  handlers: StreamHandlers,
  signal: AbortSignal,
): Promise<void> {
  if (!res.ok) {
    let message = `تعذّر الاتصال (${res.status})`;
    try {
      const body = (await res.json()) as { error?: string };
      if (body.error) message = body.error;
    } catch {
      /* keep fallback */
    }
    handlers.onError(message);
    return;
  }

  const reader = res.body?.getReader();
  if (!reader) {
    handlers.onError("تعذّر قراءة الرد.");
    return;
  }

  const decoder = new TextDecoder();
  let buffer = "";

  try {
    while (true) {
      if (signal.aborted) break;
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      let sep: number;
      while ((sep = buffer.indexOf("\n")) >= 0) {
        const line = buffer.slice(0, sep).trim();
        buffer = buffer.slice(sep + 1);
        if (!line.startsWith("data:")) continue;
        const data = line.slice(5).trim();
        if (data === "[DONE]") {
          handlers.onDone();
          return;
        }
        try {
          const json = JSON.parse(data) as {
            error?: { message?: string };
            choices?: { delta?: { content?: string } }[];
          };
          if (json.error?.message) {
            handlers.onError(json.error.message);
            return;
          }
          const piece = json.choices?.[0]?.delta?.content;
          if (piece) handlers.onDelta(piece);
        } catch {
          /* incomplete JSON — ignore */
        }
      }
    }
    handlers.onDone();
  } catch (err) {
    if (signal.aborted) {
      handlers.onDone();
      return;
    }
    handlers.onError(err instanceof Error ? err.message : "انقطع البث.");
  }
}
