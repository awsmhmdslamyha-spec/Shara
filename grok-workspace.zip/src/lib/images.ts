import { isSafeImageSrc, MAX_IMAGES_PER_MESSAGE } from "./image-src";
import type { ChatImage } from "./types";
import { uid } from "./utils";

export { isSafeImageSrc, MAX_IMAGES_PER_MESSAGE } from "./image-src";

const MAX_FILE_BYTES = 12 * 1024 * 1024;
const MAX_EDGE = 1400;
const MIN_EDGE = 8;
const TARGET_BYTES = 280_000;

function blobToDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("تعذّر تجهيز الصورة."));
    reader.onload = () => {
      const result = reader.result;
      if (typeof result !== "string") {
        reject(new Error("تعذّر تجهيز الصورة."));
        return;
      }
      resolve(result);
    };
    reader.readAsDataURL(blob);
  });
}

async function blobToDataUrlSafe(blob: Blob): Promise<string> {
  try {
    return await blobToDataUrl(blob);
  } catch {
    const buf = await blob.arrayBuffer();
    const bytes = new Uint8Array(buf);
    let binary = "";
    const chunk = 0x8000;
    for (let i = 0; i < bytes.length; i += chunk) {
      binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
    }
    const mime = blob.type && blob.type.startsWith("image/") ? blob.type : "image/jpeg";
    return `data:${mime};base64,${btoa(binary)}`;
  }
}

function loadHtmlImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const el = new Image();
    el.onload = () => resolve(el);
    el.onerror = () => reject(new Error("صيغة الصورة غير مدعومة."));
    el.src = src;
  });
}

async function decodeFile(file: File): Promise<CanvasImageSource & { width: number; height: number }> {
  if (typeof createImageBitmap === "function") {
    try {
      const bitmap = await createImageBitmap(file);
      if (bitmap.width >= 1 && bitmap.height >= 1) return bitmap;
      bitmap.close();
    } catch {
      /* try element decode */
    }
  }

  const objectUrl = URL.createObjectURL(file);
  try {
    return await loadHtmlImage(objectUrl);
  } catch {
    URL.revokeObjectURL(objectUrl);
    const dataUrl = await blobToDataUrlSafe(file);
    return await loadHtmlImage(dataUrl);
  }
}

async function canvasToJpeg(canvas: HTMLCanvasElement, quality: number): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => {
        if (!blob) reject(new Error("تعذّر تجهيز الصورة."));
        else resolve(blob);
      },
      "image/jpeg",
      quality,
    );
  });
}

function fitSize(width: number, height: number): { w: number; h: number } {
  let w = width;
  let h = height;
  const maxSide = Math.max(w, h);
  if (maxSide > MAX_EDGE) {
    const scale = MAX_EDGE / maxSide;
    w = Math.round(w * scale);
    h = Math.round(h * scale);
  }
  if (w < MIN_EDGE || h < MIN_EDGE) {
    const scale = MIN_EDGE / Math.min(w, h);
    w = Math.max(MIN_EDGE, Math.round(w * scale));
    h = Math.max(MIN_EDGE, Math.round(h * scale));
  }
  return { w, h };
}

export async function fileToChatImage(file: File): Promise<ChatImage> {
  if (!file || file.size < 32) {
    throw new Error("الملف فارغ.");
  }
  const type = (file.type || "").toLowerCase();
  if (type && !type.startsWith("image/")) {
    throw new Error("أرسل صورة (JPEG أو PNG أو WebP).");
  }
  if (file.size > MAX_FILE_BYTES) {
    throw new Error("الصورة أكبر من الحد المسموح.");
  }

  try {
    const decoded = await decodeFile(file);
    const width = Number(decoded.width);
    const height = Number(decoded.height);
    if (!width || !height) throw new Error("الصورة غير صالحة.");

    let { w, h } = fitSize(width, height);

    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("تعذّر تجهيز الصورة.");

    let quality = 0.82;
    let blob: Blob | null = null;
    for (let i = 0; i < 6; i++) {
      canvas.width = w;
      canvas.height = h;
      ctx.fillStyle = "#111113";
      ctx.fillRect(0, 0, w, h);
      ctx.drawImage(decoded, 0, 0, w, h);
      blob = await canvasToJpeg(canvas, quality);
      if (blob.size <= TARGET_BYTES) break;
      quality = Math.max(0.52, quality - 0.08);
      const next = fitSize(Math.round(w * 0.85), Math.round(h * 0.85));
      w = next.w;
      h = next.h;
    }

    if (decoded instanceof HTMLImageElement && decoded.src.startsWith("blob:")) {
      URL.revokeObjectURL(decoded.src);
    }

    if ("close" in decoded && typeof (decoded as ImageBitmap).close === "function") {
      (decoded as ImageBitmap).close();
    }

    if (!blob) throw new Error("تعذّر تجهيز الصورة.");
    const src = await blobToDataUrlSafe(blob);
    if (isSafeImageSrc(src)) return { id: uid("img"), src };
  } catch {
    /* fall back to the original file when it's already a web image */
  }

  if (/^image\/(jpeg|jpg|png|webp|gif)$/i.test(type) && file.size <= 500_000) {
    const src = await blobToDataUrlSafe(file);
    if (isSafeImageSrc(src)) return { id: uid("img"), src };
  }

  throw new Error("ما قدرت أرفق هذي الصورة. جرّب JPEG أو لقطة شاشة.");
}

export async function filesToChatImages(
  files: File[],
  already: number,
): Promise<{ images: ChatImage[]; error: string | null }> {
  const room = MAX_IMAGES_PER_MESSAGE - already;
  if (room <= 0) {
    return { images: [], error: "يمكنك إرفاق المزيد بعد إرسال هذه الرسالة." };
  }
  const picked = files.slice(0, Math.max(1, room));
  const images: ChatImage[] = [];
  let error: string | null = null;
  for (const file of picked) {
    try {
      images.push(await fileToChatImage(file));
    } catch (err) {
      error = err instanceof Error ? err.message : "تعذّر إرفاق الصورة.";
    }
  }
  if (!images.length && !error) error = "ما قدرت أرفق هذي الصورة. جرّب JPEG أو لقطة شاشة.";
  return { images, error };
}
