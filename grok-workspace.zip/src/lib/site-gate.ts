const TOKEN_KEY = "sahra-gate-token";
export const GATE_LOCKED_EVENT = "sahra:locked";

function dropPersistedToken() {
  try {
    localStorage.removeItem(TOKEN_KEY);
  } catch {
    /* private mode */
  }
}

export function getGateToken(): string | null {
  dropPersistedToken();
  try {
    return sessionStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}

export function setGateToken(token: string) {
  dropPersistedToken();
  try {
    sessionStorage.setItem(TOKEN_KEY, token);
  } catch {
    /* private mode */
  }
}

export function clearGateToken() {
  dropPersistedToken();
  try {
    sessionStorage.removeItem(TOKEN_KEY);
  } catch {
    /* private mode */
  }
}

export function gateHeaders(): Record<string, string> {
  const token = getGateToken();
  return token ? { Authorization: `Bearer ${token}` } : {};
}

export function emitGateLocked() {
  if (typeof window !== "undefined") {
    window.dispatchEvent(new Event(GATE_LOCKED_EVENT));
  }
}

export async function lockSite() {
  clearGateToken();
  try {
    await fetch("/api/gate", { method: "DELETE", credentials: "include" });
  } catch {
    /* still lock locally */
  }
  emitGateLocked();
}
