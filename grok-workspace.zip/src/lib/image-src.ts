export const MAX_IMAGES_PER_MESSAGE = 4;
export const MAX_IMAGE_SRC_CHARS = 700_000;

export function isSafeImageSrc(src: unknown): src is string {
  if (typeof src !== "string") return false;
  if (src.length < 32 || src.length > MAX_IMAGE_SRC_CHARS) return false;
  return /^data:image\/(jpeg|jpg|png|webp|gif);base64,[A-Za-z0-9+/=\s]+$/i.test(src);
}
