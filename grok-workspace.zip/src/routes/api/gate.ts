import { createFileRoute } from "@tanstack/react-router";
import {
  clearGateCookieHeader,
  gateCookieHeader,
  gateLockout,
  readGateToken,
  verifyGateToken,
  verifyPasswordAttempt,
} from "@/lib/site-gate.server";

const NO_STORE = { "Cache-Control": "no-store" };

export const Route = createFileRoute("/api/gate")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const ok = await verifyGateToken(readGateToken(request));
        const headers: Record<string, string> = { ...NO_STORE };
        if (!ok) headers["Set-Cookie"] = clearGateCookieHeader(request);
        return Response.json({ ok }, { headers });
      },

      POST: async ({ request }) => {
        const lock = gateLockout(request);
        if (lock.locked) {
          return Response.json(
            { ok: false, error: "محاولات كثيرة. انتظر قليلاً ثم أعد المحاولة." },
            {
              headers: {
                ...NO_STORE,
                "Retry-After": String(lock.retryAfterSec),
              },
            },
          );
        }

        let body: { password?: unknown } = {};
        try {
          body = (await request.json()) as { password?: unknown };
        } catch {
          return Response.json({ error: "طلب غير صالح." }, { status: 400, headers: NO_STORE });
        }

        const result = await verifyPasswordAttempt(request, body.password);
        if (!result.ok) {
          const error =
            result.status === 429
              ? "محاولات كثيرة. انتظر قليلاً ثم أعد المحاولة."
              : "كلمة السر غير صحيحة.";
          const headers: Record<string, string> = { ...NO_STORE };
          if (result.status === 429) {
            headers["Retry-After"] = String(result.retryAfterSec ?? 600);
          }
          return Response.json({ ok: false, error }, { headers });
        }

        return Response.json(
          { ok: true, token: result.token },
          {
            headers: {
              ...NO_STORE,
              "Set-Cookie": gateCookieHeader(result.token, request),
            },
          },
        );
      },

      DELETE: async ({ request }) => {
        return Response.json(
          { ok: true },
          {
            headers: {
              ...NO_STORE,
              "Set-Cookie": clearGateCookieHeader(request),
            },
          },
        );
      },
    },
  },
});
