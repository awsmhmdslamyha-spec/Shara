import { createFileRoute } from "@tanstack/react-router";
import { requireGate } from "@/lib/site-gate.server";
import {
  MAX_HISTORY,
  MAX_MESSAGE_CHARS,
  MAX_TOKENS,
  MAX_VISION_TURNS,
  MODEL,
} from "@/lib/defaults";
import { isSafeImageSrc, MAX_IMAGES_PER_MESSAGE } from "@/lib/image-src";
import { composeSystemPrompt } from "@/lib/prompt";
import type { ChatImage, Frankness, PersonaPayload, Role } from "@/lib/types";
import { clamp } from "@/lib/utils";

type Incoming = {
  conversationId?: string;
  messages?: {
    role?: string;
    content?: string;
    images?: { src?: string }[];
  }[];
  persona?: Partial<PersonaPayload>;
};

type ParsedMessage = {
  role: Role;
  content: string;
  images: ChatImage[];
};

type XaiPart =
  | { type: "text"; text: string }
  | { type: "image_url"; image_url: { url: string; detail: "high" } };

function asFrankness(n: unknown): Frankness {
  const v = Number(n);
  if (v <= 1) return 1;
  if (v === 2) return 2;
  if (v === 3) return 3;
  if (v === 4) return 4;
  return 5;
}

function parseImages(raw: { src?: string }[] | undefined): ChatImage[] {
  if (!Array.isArray(raw)) return [];
  const out: ChatImage[] = [];
  for (const item of raw) {
    if (!isSafeImageSrc(item?.src)) continue;
    out.push({ id: `img_${out.length}`, src: item.src });
    if (out.length >= MAX_IMAGES_PER_MESSAGE) break;
  }
  return out;
}

function parseBody(raw: Incoming): {
  conversationId: string;
  messages: ParsedMessage[];
  persona: PersonaPayload;
} | { error: string } {
  const messages = (raw.messages ?? [])
    .map((m) => {
      const role = m.role === "user" || m.role === "assistant" ? m.role : null;
      if (!role) return null;
      const content = typeof m.content === "string" ? m.content.slice(0, MAX_MESSAGE_CHARS) : "";
      const images = role === "user" ? parseImages(m.images) : [];
      if (!content.trim() && !images.length) return null;
      return { role, content, images };
    })
    .filter((m): m is ParsedMessage => m !== null)
    .slice(-MAX_HISTORY);

  if (!messages.length) return { error: "اكتب رسالة أو أرفق صورة." };
  if (messages.at(-1)?.role !== "user") {
    return { error: "آخر رسالة يجب أن تكون منك." };
  }

  const p = raw.persona ?? {};
  const persona: PersonaPayload = {
    name: String(p.name ?? "سهرة").slice(0, 80),
    role: String(p.role ?? "").slice(0, 400),
    tone: String(p.tone ?? "").slice(0, 400),
    style: String(p.style ?? "").slice(0, 600),
    frankness: asFrankness(p.frankness),
    boundaries: String(p.boundaries ?? "").slice(0, 2000),
    instructions: String(p.instructions ?? "").slice(0, 4000),
    temperature: clamp(Number(p.temperature ?? 0.9) || 0.9, 0.2, 1.2),
  };

  return {
    conversationId: String(raw.conversationId ?? "anon").slice(0, 80),
    messages,
    persona,
  };
}

function toXaiMessages(messages: ParsedMessage[]) {
  let visionLeft = MAX_VISION_TURNS;
  const keepVision = new Set<number>();
  for (let i = messages.length - 1; i >= 0; i--) {
    const m = messages[i]!;
    if (m.role === "user" && m.images.length && visionLeft > 0) {
      keepVision.add(i);
      visionLeft -= 1;
    }
  }

  return messages.map((m, i) => {
    const includeImages = keepVision.has(i);
    if (m.role === "assistant" || (!includeImages && !m.images.length)) {
      return { role: m.role, content: m.content };
    }
    if (!includeImages && m.images.length) {
      const note = m.content.trim()
        ? `${m.content}\n\n(أُرفقت صورة في هذه الرسالة.)`
        : "أرفقت صورة في هذه الرسالة.";
      return { role: m.role, content: note };
    }
    const text =
      m.content.trim() ||
      "انظر إلى الصورة وأجب بدقة عما تراه، ثم عن السؤال إن وُجد.";
    const parts: XaiPart[] = [
      ...m.images.map((img) => ({
        type: "image_url" as const,
        image_url: { url: img.src, detail: "high" as const },
      })),
      { type: "text", text },
    ];
    return { role: m.role, content: parts };
  });
}

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const denied = await requireGate(request);
        if (denied) return denied;

        const apiKey = process.env.XAI_API_KEY;
        if (!apiKey) {
          return Response.json(
            { error: "المحادثة غير متاحة في هذه البيئة." },
            { status: 503 },
          );
        }

        let raw: Incoming;
        try {
          raw = (await request.json()) as Incoming;
        } catch {
          return Response.json({ error: "طلب غير صالح." }, { status: 400 });
        }

        const parsed = parseBody(raw);
        if ("error" in parsed) {
          return Response.json({ error: parsed.error }, { status: 400 });
        }

        const system = composeSystemPrompt(parsed.persona);

        const res = await fetch("https://api.x.ai/v1/chat/completions", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${apiKey}`,
            "x-grok-conv-id": parsed.conversationId,
          },
          body: JSON.stringify({
            model: MODEL,
            stream: true,
            temperature: parsed.persona.temperature,
            max_tokens: MAX_TOKENS,
            messages: [{ role: "system", content: system }, ...toXaiMessages(parsed.messages)],
          }),
        });

        if (!res.ok || !res.body) {
          let detail = `xAI API error ${res.status}`;
          try {
            const errBody = (await res.json()) as {
              error?: { message?: string } | string;
            };
            if (typeof errBody.error === "string") detail = errBody.error;
            else if (errBody.error?.message) detail = errBody.error.message;
          } catch {
            /* keep fallback */
          }
          return Response.json({ error: detail }, { status: 502 });
        }

        return new Response(res.body, {
          headers: {
            "Content-Type": "text/event-stream; charset=utf-8",
            "Cache-Control": "no-cache, no-transform",
            Connection: "keep-alive",
          },
        });
      },
    },
  },
});
