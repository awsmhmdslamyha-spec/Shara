import { createFileRoute } from "@tanstack/react-router";
import { ChatApp } from "@/components/chat-app";
import { SiteGate } from "@/components/site-gate";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <SiteGate>
      <ChatApp />
    </SiteGate>
  );
}
