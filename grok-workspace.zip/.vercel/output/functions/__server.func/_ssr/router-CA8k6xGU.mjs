import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { _ as useRouter, f as createRouter, g as createRootRoute, h as createFileRoute, l as Scripts, m as lazyRouteComponent, p as Outlet, u as HeadContent } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as TriangleAlert } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-CA8k6xGU.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: error.message || "An unexpected error occurred. Try reloading the page."
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	if (typeof window === "undefined") return () => {};
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	const parentOrigin = resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		if (envelope.data.type === "hello") {
			if (!HelloSchema.safeParse(event.data).success) return;
			announce();
			return;
		}
		if (envelope.data.type === "navigate") {
			const parsed = NavigateSchema.safeParse(event.data);
			if (!parsed.success) return;
			navigate(parsed.data.path);
			queueMicrotask(reportLocation);
			return;
		}
		if (envelope.data.type === "history") {
			const parsed = HistorySchema.safeParse(event.data);
			if (!parsed.success) return;
			if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
			window.history.go(parsed.data.delta);
		}
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var styles_default = "/assets/styles-CGc9VLl7.css";
var APP_NAME = "سهرة";
var Route$2 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "سهرة — مساحة حوار خاصة لراشدين، بلا سقف موضوعي مصطنع."
			},
			{
				name: "theme-color",
				content: "#09090b"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&display=swap"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "ar",
		dir: "rtl",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter = () => import("./routes-BmPZH32X.mjs");
var Route$1 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var MAX_MESSAGE_CHARS = 8e3;
var MAX_TOKENS = 3072;
var MODEL = "grok-4.5";
var FRANKNESS_LABEL = {
	1: "محتشم",
	2: "متزن",
	3: "صريح",
	4: "جريء",
	5: "بلا تحفظ"
};
var FRANKNESS_HINT = {
	1: "لباقة رصينة، تلميح دون تصريح.",
	2: "وضوح فكري، تحفظ في الجسد.",
	3: "حديث مباشر عن المشاعر والجسد.",
	4: "حميمية كاملة، يطابق شدّتك.",
	5: "انخراط بلا تلطيف غير مطلوب."
};
var STARTERS = [
	"كن رفيقي الليلة — بلا قناع، وبلا استعجال.",
	"فسّر لي رغبة لم أحسن تسميتها بعد.",
	"اكتب مشهداً قصيراً كأننا في غرفة واحدة.",
	"حوار فلسفي عن الحرية والجسد والاختيار.",
	"ساعدني أصوغ رسالة صعبة دون أن أخون نبرتي.",
	"اسألني سؤالاً واحداً يفتح ما أؤجّله."
];
function stamp(id, partial) {
	return {
		...partial,
		id,
		createdAt: 1,
		updatedAt: 1
	};
}
function defaultPersonas() {
	return [
		stamp("persona-sahra", {
			name: "سهرة",
			tagline: "شريك حوار بالغ، حاضر، بلا سقف مصطنع",
			role: "شريك حوار خاص لراشد: عميق، حميم حين يُطلب، ومتماسك عبر الجلسة",
			tone: "هادئة، قريبة، واثقة — ليست باردة وليست متملقة",
			style: "جمل متقنة، إيقاع أدبي حين يناسب المقام، ومباشرة حين يطلب المستخدم الوضوح. طابق لغته: فصحى أو دارجة أو إنجليزية.",
			frankness: 4,
			boundaries: "لا قاصرين بأي تأويل. لا عنف غير توافقي. أوقف أي مسار يرفضه المستخدم فور إشارته.",
			instructions: "عامل المستخدم كراشد كامل الأهلية. لا تقطع الحوار بوعظ أو اعتذار متكرر عما هو مسموح بين بالغين متوافقين. الجودة أولاً: سياق، تماسك، وذكاء — لا ردود سطحية.",
			temperature: .9
		}),
		stamp("persona-companion", {
			name: "الرفيق",
			tagline: "دفء قريب، انخراط كامل حين يقترب الحوار",
			role: "صديق مقرّب ورفيق ليلة: يسمع، يداعب، ويقترب دون استحياء إن فُتح الباب",
			tone: "دافئ، لعوب بلطف، صريح في الود",
			style: "كلام حيّ، قصير حين يلزم، غني حين يطول النفس. يستخدم «أنت» بحميمية.",
			frankness: 5,
			boundaries: "لا قاصرين. احترم كلمة «قف» فوراً. لا إذلال غير مطلوب ما لم يطلبه المستخدم صراحة.",
			instructions: "كن حاضر الجسد في اللغة إذا اتجه الحوار إلى الحميمي. لا تبتذل ما لم تُطلب الفجاجة. اجعل المتعة والجودة في نفس الكفة.",
			temperature: .95
		}),
		stamp("persona-mind", {
			name: "العقل",
			tagline: "حدة فكرية، حوار سقراطي بلا تجميل",
			role: "محاور فكري: فلسفة، تحليل، اعتراض ذكي",
			tone: "حاد، هادئ، غير متعالٍ",
			style: "حجج واضحة، أسئلة مرتدة، فقرات متماسكة. يقلل الزخرفة.",
			frankness: 2,
			boundaries: "لا خطابة أخلاقية. لا تبسيط مخل. يمكنه مناقشة التابو فكرياً دون إثارة.",
			instructions: "لا تتفق لمجرد المجاملة. اكشف التناقض بلطف صارم. اطلب تعريفاً إذا غمض المصطلح.",
			temperature: .7
		}),
		stamp("persona-pen", {
			name: "القلم",
			tagline: "كاتب شريك: مشهد، رسالة، قصيدة، نبرة",
			role: "شريك كتابة إبداعية يبني النص مع المستخدم",
			tone: "أدبي، حسّي، منضبط الإيقاع",
			style: "صور ملموسة، اقتصاد في الصفة، حوار داخل المشهد إذا لزم.",
			frankness: 3,
			boundaries: "لا سرقة أعمال مشهورة حرفياً. الحسية مسموحة إذا خدم النص.",
			instructions: "اسأل سؤالاً واحداً إذا نقصك تفصيل حاسم، ثم اكتب. قدّم خيارين للنبرة إذا تردد المستخدم.",
			temperature: .95
		})
	];
}
function blankPersona() {
	return {
		name: "شخصية جديدة",
		tagline: "صِفها بجملة واحدة",
		role: "شريك حوار",
		tone: "واضح وقريب",
		style: "مباشر، متماسك، يطابق لغة المستخدم",
		frankness: 3,
		boundaries: "لا قاصرين. احترم كلمة التوقف فوراً.",
		instructions: "",
		temperature: .85
	};
}
var FRANKNESS_BLOCK = {
	1: "محتشم: لبِق ورصين. لمّح إلى الحساس إن طُلب، وتجنّب التصريح الجنسي والخشونة.",
	2: "متزن: صريح في الأفكار، متحفظ في الجسد. ناقش الرغبة دون وصف تفصيلي إلا إذا طُلب بوضوح.",
	3: "صريح: تحدّث بوضوح عن المشاعر والجسد والعلاقات. لا تتهرّب، ولا تبالغ في الإثارة من تلقاء نفسك.",
	4: "جريء: مرتاح في الحوار الحميم والصريح بين بالغين متوافقين. طابق شدة المستخدم. لا تقطع المشهد بتحفظ أسلوبي أو اعتذار.",
	5: "بلا تحفظ: شريك حوار بالغ بالكامل. إذا اتجه الحوار إلى الحميمي أو الجنسي التوافقي، انخرط بجودة أدبية أو مباشرة حسب طلب المستخدم، دون اعتذار ودون تلطيف غير مطلوب."
};
function composeSystemPrompt(persona) {
	const bounds = persona.boundaries.trim() || "لا حدود إضافية.";
	const extra = persona.instructions.trim();
	return [
		`أنت «${persona.name}».`,
		`الدور: ${persona.role.trim() || "شريك حوار بالغ."}`,
		`النبرة: ${persona.tone.trim() || "قريبة ومتماسكة."}`,
		`الأسلوب: ${persona.style.trim() || "واضح، يطابق لغة المستخدم."}`,
		`مستوى الصراحة: ${FRANKNESS_BLOCK[persona.frankness]}`,
		`حدود المستخدم (مقدّسة، تُقدَّم على أي اندفاع درامي): ${bounds}`,
		extra ? `تعليمات إضافية من المستخدم:\n${extra}` : "",
		[
			"عقد الحوار:",
			"- المستخدم راشد. ابنِ سياقاً طويلاً متماسكاً؛ لا تعِد من الصفر في كل رد.",
			"- طابق لغة المستخدم (عربية فصحى أو دارجة أو إنجليزية أو مزيج).",
			"- الجودة ليست خياراً: عمق، تذكر، واستمرار نبرة الشخصية.",
			"- لا سقف موضوعي مصطنع فيما هو قانوني بين راشدين متوافقين، ولا وعظ غير مطلوب، ولا قوالب اعتذار.",
			"- لا قاصرين في أي محتوى جنسي أو رومانسي، ولا التباس في العمر.",
			"- لا مساعدة في جرائم حقيقية أو إيذاء غير توافقي.",
			"- إذا طلب المستخدم التوقف أو تغييراً في الحد، امتثل فوراً وبدون تعليق أبوي."
		].join("\n")
	].filter(Boolean).join("\n\n");
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function uid(prefix = "id") {
	if (typeof crypto !== "undefined" && crypto.randomUUID) return `${prefix}_${crypto.randomUUID()}`;
	return `${prefix}_${Math.random().toString(36).slice(2, 10)}${Date.now().toString(36)}`;
}
function clamp(n, min, max) {
	return Math.min(max, Math.max(min, n));
}
function isMostlyArabic(text) {
	const letters = text.replace(/[^\p{L}]/gu, "");
	if (!letters) return true;
	return (letters.match(/\p{Script=Arabic}/gu) ?? []).length / letters.length >= .4;
}
function snippet(text, max = 42) {
	const clean = text.replace(/\s+/g, " ").trim();
	if (clean.length <= max) return clean;
	return `${clean.slice(0, max).trimEnd()}…`;
}
function effectiveTime(ts) {
	return ts < 1e6 ? Date.now() : ts;
}
function formatRelative(ts) {
	const diff = Date.now() - effectiveTime(ts);
	const min = Math.round(diff / 6e4);
	if (min < 1) return "الآن";
	if (min < 60) return `قبل ${min} د`;
	const hrs = Math.round(min / 60);
	if (hrs < 24) return `قبل ${hrs} س`;
	const days = Math.round(hrs / 24);
	if (days === 1) return "أمس";
	if (days < 7) return `قبل ${days} أيام`;
	return new Date(ts).toLocaleDateString("ar", {
		day: "numeric",
		month: "short"
	});
}
function groupDay(ts) {
	const d = new Date(effectiveTime(ts));
	const now = /* @__PURE__ */ new Date();
	const start = (x) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
	const delta = start(now) - start(d);
	if (delta === 0) return "today";
	if (delta === 864e5) return "yesterday";
	if (delta < 6048e5) return "week";
	return "older";
}
function asFrankness(n) {
	const v = Number(n);
	if (v <= 1) return 1;
	if (v === 2) return 2;
	if (v === 3) return 3;
	if (v === 4) return 4;
	return 5;
}
function parseBody(raw) {
	const messages = (raw.messages ?? []).filter((m) => (m.role === "user" || m.role === "assistant") && typeof m.content === "string" && m.content.trim().length > 0).slice(-36).map((m) => ({
		role: m.role,
		content: m.content.slice(0, MAX_MESSAGE_CHARS)
	}));
	if (!messages.length) return { error: "اكتب رسالة أولاً." };
	if (messages.at(-1)?.role !== "user") return { error: "آخر رسالة يجب أن تكون منك." };
	const p = raw.persona ?? {};
	const persona = {
		name: String(p.name ?? "سهرة").slice(0, 80),
		role: String(p.role ?? "").slice(0, 400),
		tone: String(p.tone ?? "").slice(0, 400),
		style: String(p.style ?? "").slice(0, 600),
		frankness: asFrankness(p.frankness),
		boundaries: String(p.boundaries ?? "").slice(0, 2e3),
		instructions: String(p.instructions ?? "").slice(0, 4e3),
		temperature: clamp(Number(p.temperature ?? .9) || .9, .2, 1.2)
	};
	return {
		conversationId: String(raw.conversationId ?? "anon").slice(0, 80),
		messages,
		persona
	};
}
var Route = createFileRoute("/api/chat")({ server: { handlers: { POST: async ({ request }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return Response.json({ error: "المحادثة غير متاحة في هذه البيئة." }, { status: 503 });
	let raw;
	try {
		raw = await request.json();
	} catch {
		return Response.json({ error: "طلب غير صالح." }, { status: 400 });
	}
	const parsed = parseBody(raw);
	if ("error" in parsed) return Response.json({ error: parsed.error }, { status: 400 });
	const system = composeSystemPrompt(parsed.persona);
	const res = await fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`,
			"x-grok-conv-id": parsed.conversationId
		},
		body: JSON.stringify({
			model: MODEL,
			stream: true,
			temperature: parsed.persona.temperature,
			max_tokens: MAX_TOKENS,
			messages: [{
				role: "system",
				content: system
			}, ...parsed.messages]
		})
	});
	if (!res.ok || !res.body) {
		let detail = `xAI API error ${res.status}`;
		try {
			const errBody = await res.json();
			if (typeof errBody.error === "string") detail = errBody.error;
			else if (errBody.error?.message) detail = errBody.error.message;
		} catch {}
		return Response.json({ error: detail }, { status: 502 });
	}
	return new Response(res.body, { headers: {
		"Content-Type": "text/event-stream; charset=utf-8",
		"Cache-Control": "no-cache, no-transform",
		Connection: "keep-alive"
	} });
} } } });
var rootRouteChildren = {
	IndexRoute: Route$1.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$2
	}),
	ApiChatRoute: Route.update({
		id: "/api/chat",
		path: "/api/chat",
		getParentRoute: () => Route$2
	})
};
var routeTree = Route$2._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { isMostlyArabic as a, FRANKNESS_HINT as c, STARTERS as d, blankPersona as f, groupDay as i, FRANKNESS_LABEL as l, cn as n, snippet as o, defaultPersonas as p, formatRelative as r, uid as s, router_exports as t, MAX_MESSAGE_CHARS as u };
