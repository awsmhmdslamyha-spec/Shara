import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as SlidersHorizontal, c as Plus, d as Menu, f as Copy, i as Square, l as Pencil, m as ArrowUp, o as Search, p as Check, r as Trash2, s as RefreshCw, t as X, u as MessageSquarePlus } from "../_libs/lucide-react.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { a as isMostlyArabic, c as FRANKNESS_HINT, d as STARTERS, f as blankPersona, i as groupDay, l as FRANKNESS_LABEL, n as cn, o as snippet, p as defaultPersonas, r as formatRelative, s as uid, u as MAX_MESSAGE_CHARS } from "./router-CA8k6xGU.mjs";
import { n as create, r as useShallow, t as persist } from "../_libs/zustand.mjs";
import { t as Markdown } from "../_libs/react-markdown+[...].mjs";
import { t as remarkGfm } from "../_libs/remark-gfm.mjs";
import { a as DialogPortal, i as DialogOverlay, n as DialogClose, o as DialogTitle, r as DialogContent$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BmPZH32X.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Composer({ value, onChange, onSubmit, onStop, disabled, streaming, placeholder }) {
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const el = ref.current;
		if (!el) return;
		el.style.height = "auto";
		el.style.height = `${Math.min(el.scrollHeight, 200)}px`;
	}, [value]);
	function handleKey(e) {
		if (e.nativeEvent.isComposing) return;
		if (e.key === "Enter" && !e.shiftKey) {
			e.preventDefault();
			if (!streaming && value.trim()) onSubmit();
		}
	}
	function handleSubmit(e) {
		e.preventDefault();
		if (streaming) {
			onStop();
			return;
		}
		if (value.trim()) onSubmit();
	}
	const dir = isMostlyArabic(value) || !value.trim() ? "rtl" : "ltr";
	const over = value.length > MAX_MESSAGE_CHARS;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: handleSubmit,
		className: "mx-auto w-full max-w-3xl px-3 pb-4 pt-2 sm:px-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("flex items-end gap-2 rounded-2xl bg-elevated p-2 ps-4 shadow-[var(--shadow-border)]", "focus-within:shadow-[var(--shadow-border-hover)]"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				ref,
				dir,
				rows: 1,
				value,
				onChange: (e) => onChange(e.target.value),
				onKeyDown: handleKey,
				placeholder,
				disabled: disabled && !streaming,
				className: "max-h-52 min-h-11 flex-1 resize-none bg-transparent py-2.5 text-[0.98rem] leading-relaxed text-fg outline-none placeholder:text-subtle disabled:opacity-60"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "submit",
				disabled: !streaming && (!value.trim() || disabled || over),
				className: cn("mb-0.5 inline-flex size-11 shrink-0 items-center justify-center rounded-xl transition-transform duration-150 active:enabled:scale-[0.96]", streaming ? "bg-fg text-bg" : "bg-accent text-accent-fg disabled:opacity-30"),
				"aria-label": streaming ? "إيقاف" : "إرسال",
				children: streaming ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, { className: "size-3.5 fill-current" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { className: "size-5" })
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-2 flex items-center justify-between px-1 text-[0.7rem] text-subtle",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "hidden sm:inline",
				children: "Enter للإرسال · Shift+Enter لسطر جديد"
			}), over ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-danger",
				children: "تجاوزت حد الرسالة"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "tabular-nums",
				children: value.length ? `${value.length} / ${MAX_MESSAGE_CHARS}` : ""
			})]
		})]
	});
}
function MessageMarkdown({ content }) {
	const dir = isMostlyArabic(content) ? "rtl" : "ltr";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		dir,
		className: cn("max-w-none text-[0.98rem] leading-[1.75] text-fg", "[&_p]:mb-3 [&_p:last-child]:mb-0", "[&_h1]:mb-3 [&_h1]:text-xl [&_h1]:font-medium", "[&_h2]:mb-2.5 [&_h2]:text-lg [&_h2]:font-medium", "[&_h3]:mb-2 [&_h3]:text-base [&_h3]:font-medium", "[&_ul]:mb-3 [&_ul]:list-disc [&_ul]:ps-5", "[&_ol]:mb-3 [&_ol]:list-decimal [&_ol]:ps-5", "[&_li]:mb-1", "[&_blockquote]:mb-3 [&_blockquote]:border-s-2 [&_blockquote]:border-border-strong [&_blockquote]:ps-3 [&_blockquote]:text-muted", "[&_a]:text-accent [&_a]:underline [&_a]:underline-offset-4", "[&_hr]:my-5 [&_hr]:border-border", "[&_code]:rounded-md [&_code]:bg-elevated [&_code]:px-1.5 [&_code]:py-0.5 [&_code]:font-mono [&_code]:text-[0.85em]", "[&_pre]:mb-3 [&_pre]:overflow-x-auto [&_pre]:rounded-xl [&_pre]:bg-elevated [&_pre]:p-3 [&_pre]:shadow-[var(--shadow-border)]", "[&_pre_code]:bg-transparent [&_pre_code]:p-0", "[&_strong]:font-medium"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Markdown, {
			remarkPlugins: [remarkGfm],
			components: { a: ({ href, children }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href,
				target: "_blank",
				rel: "noreferrer noopener",
				children
			}) },
			children: content
		})
	});
}
function EmptyHero({ persona, onPick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex w-full max-w-2xl flex-1 flex-col items-center justify-center px-5 py-10 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "sahra-enter",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-4xl font-medium tracking-tight sm:text-5xl",
					children: "سهرة"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mx-auto mt-3 max-w-md text-sm leading-relaxed text-muted",
					children: "مساحة حوار خاصة لراشدين. بلا سقف موضوعي مصطنع، وبلا ردود سطحية — غيّر الشخصية كما تشاء."
				}),
				persona ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-xs text-subtle",
					children: [
						"الآن: ",
						persona.name,
						" · ",
						persona.tagline
					]
				}) : null
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-8 flex w-full flex-col gap-2 md:grid md:grid-cols-2",
			children: STARTERS.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => onPick(s),
				style: { animationDelay: `${120 + i * 40}ms` },
				className: "sahra-enter rounded-2xl bg-elevated px-4 py-3.5 text-start text-sm leading-relaxed text-muted shadow-[var(--shadow-border)] hover:text-fg hover:shadow-[var(--shadow-border-hover)]",
				children: s
			}, s))
		})]
	});
}
function UserBubble({ content }) {
	const dir = isMostlyArabic(content) ? "rtl" : "ltr";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			dir,
			className: "ml-auto max-w-[min(100%,42rem)] rounded-2xl rounded-br-md bg-elevated px-4 py-3 text-[0.98rem] leading-[1.7] whitespace-pre-wrap shadow-[var(--shadow-border)]",
			children: content
		})
	});
}
function AssistantBlock({ content, streaming, onRegenerate, showRegen }) {
	const [copied, setCopied] = (0, import_react.useState)(false);
	async function copy() {
		try {
			await navigator.clipboard.writeText(content);
			setCopied(true);
			window.setTimeout(() => setCopied(false), 1400);
		} catch {}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "group",
		children: [
			content ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageMarkdown, { content }) : streaming ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "sahra-shimmer bg-clip-text text-sm text-transparent",
				children: "يكتب…"
			}) : null,
			streaming && content ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "sahra-caret ms-0.5 inline-block h-4 w-1.5 translate-y-0.5 rounded-sm bg-accent align-middle" }) : null,
			!streaming && content ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex gap-1 opacity-100 sm:opacity-0 sm:transition-opacity sm:group-hover:opacity-100",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: copy,
					className: "inline-flex h-8 items-center gap-1.5 rounded-lg px-2 text-xs text-subtle hover:bg-elevated hover:text-fg",
					children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-3.5" }), copied ? "نُسخ" : "نسخ"]
				}), showRegen && onRegenerate ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: onRegenerate,
					className: "inline-flex h-8 items-center gap-1.5 rounded-lg px-2 text-xs text-subtle hover:bg-elevated hover:text-fg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "size-3.5" }), "إعادة توليد"]
				}) : null]
			}) : null
		]
	});
}
function MessageList({ messages, streamingId, persona, error, onPickStarter, onRegenerate }) {
	const scroller = (0, import_react.useRef)(null);
	const bottom = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		bottom.current?.scrollIntoView({ block: "end" });
	}, [
		messages,
		streamingId,
		messages.at(-1)?.content
	]);
	if (!messages.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyHero, {
		persona,
		onPick: onPickStarter
	});
	const lastAssistant = [...messages].reverse().find((m) => m.role === "assistant");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: scroller,
		className: "min-h-0 flex-1 overflow-y-auto scrollbar-thin",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex w-full max-w-3xl flex-col gap-6 px-4 py-6 sm:px-6",
			children: [
				messages.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn(m.role === "assistant" && "pe-2"),
					children: m.role === "user" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserBubble, { content: m.content }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AssistantBlock, {
						content: m.content,
						streaming: streamingId === m.id,
						showRegen: lastAssistant?.id === m.id && streamingId === null,
						onRegenerate
					})
				}, m.id)),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-xl bg-danger/10 px-4 py-3 text-sm text-danger",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { ref: bottom })
			]
		})
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 font-medium transition-[opacity,transform,background-color,color,box-shadow] duration-150 ease-out disabled:pointer-events-none disabled:opacity-40 active:enabled:scale-[0.96] select-none", {
	variants: {
		variant: {
			primary: "bg-accent text-accent-fg shadow-[var(--shadow-border)] hover:opacity-90",
			ghost: "bg-transparent text-fg hover:bg-elevated",
			outline: "bg-transparent text-fg shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)] hover:bg-elevated",
			subtle: "bg-elevated text-fg hover:bg-elevated/80",
			danger: "bg-danger/15 text-danger hover:bg-danger/25"
		},
		size: {
			sm: "h-9 rounded-lg px-3 text-sm",
			md: "h-11 rounded-xl px-4 text-sm",
			lg: "h-12 rounded-2xl px-5 text-base",
			icon: "size-11 rounded-xl",
			"icon-sm": "size-9 rounded-lg"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
var Button = (0, import_react.forwardRef)(function Button({ className, variant, size, type = "button", ...props }, ref) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		ref,
		type,
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
});
var Dialog = Dialog$1;
function DialogContent({ className, children, title }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-50 bg-bg/70 data-[state=open]:animate-[sahra-rise_200ms_var(--ease-out)]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
		className: cn("fixed top-1/2 left-1/2 z-50 flex max-h-[min(92dvh,880px)] w-[min(100%-1.5rem,720px)] -translate-x-1/2 -translate-y-1/2 flex-col overflow-hidden rounded-2xl bg-surface shadow-[var(--shadow-float),var(--shadow-border)]", "data-[state=open]:animate-[sahra-rise_250ms_var(--ease-out)]", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-3 border-b border-border px-5 py-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
				className: "text-base font-medium",
				children: title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
				className: "inline-flex size-9 items-center justify-center rounded-lg text-muted hover:bg-elevated hover:text-fg",
				"aria-label": "إغلاق",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "min-h-0 flex-1 overflow-y-auto scrollbar-thin",
			children
		})]
	})] });
}
var Input = (0, import_react.forwardRef)(function Input({ className, ...props }, ref) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		ref,
		className: cn("h-11 w-full rounded-xl bg-elevated px-3.5 text-sm text-fg placeholder:text-subtle", "shadow-[var(--shadow-border)] outline-none", "focus:shadow-[var(--shadow-border-hover)]", className),
		...props
	});
});
var Textarea = (0, import_react.forwardRef)(function Textarea({ className, ...props }, ref) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		ref,
		className: cn("min-h-24 w-full resize-y rounded-xl bg-elevated px-3.5 py-3 text-sm leading-relaxed text-fg placeholder:text-subtle", "shadow-[var(--shadow-border)] outline-none", "focus:shadow-[var(--shadow-border-hover)]", className),
		...props
	});
});
function seed() {
	const personas = defaultPersonas();
	const personaId = personas[0].id;
	const conv = {
		id: "conv-welcome",
		title: "حوار جديد",
		personaId,
		messages: [],
		createdAt: 1,
		updatedAt: 1
	};
	return {
		personas,
		conversations: [conv],
		activeConversationId: conv.id,
		activePersonaId: personaId
	};
}
var useSahraStore = create()(persist((set, get) => ({
	hydrated: false,
	...seed(),
	sidebarOpen: false,
	streamingId: null,
	error: null,
	hydrateDefaults: () => {
		const s = get();
		const patch = { hydrated: true };
		if (!s.personas.length) {
			const seeded = seed();
			Object.assign(patch, seeded);
		} else if (!s.conversations.length) {
			const personaId = s.activePersonaId ?? s.personas[0].id;
			const conv = {
				id: uid("conv"),
				title: "حوار جديد",
				personaId,
				messages: [],
				createdAt: Date.now(),
				updatedAt: Date.now()
			};
			patch.conversations = [conv];
			patch.activeConversationId = conv.id;
			patch.activePersonaId = personaId;
		}
		set(patch);
	},
	setSidebarOpen: (open) => set({ sidebarOpen: open }),
	setError: (error) => set({ error }),
	newConversation: (personaId) => {
		const s = get();
		const pid = personaId ?? s.activePersonaId ?? s.personas[0]?.id ?? seed().activePersonaId;
		const conv = {
			id: uid("conv"),
			title: "حوار جديد",
			personaId: pid,
			messages: [],
			createdAt: Date.now(),
			updatedAt: Date.now()
		};
		set({
			conversations: [conv, ...s.conversations],
			activeConversationId: conv.id,
			activePersonaId: pid,
			sidebarOpen: false,
			error: null
		});
		return conv.id;
	},
	setActiveConversation: (id) => {
		const conv = get().conversations.find((c) => c.id === id);
		if (!conv) return;
		set({
			activeConversationId: id,
			activePersonaId: conv.personaId,
			sidebarOpen: false,
			error: null
		});
	},
	renameConversation: (id, title) => {
		const t = title.trim() || "حوار بلا عنوان";
		set({ conversations: get().conversations.map((c) => c.id === id ? {
			...c,
			title: t,
			updatedAt: Date.now()
		} : c) });
	},
	deleteConversation: (id) => {
		const s = get();
		const rest = s.conversations.filter((c) => c.id !== id);
		if (!rest.length) {
			const pid = s.activePersonaId ?? s.personas[0]?.id ?? seed().activePersonaId;
			const conv = {
				id: uid("conv"),
				title: "حوار جديد",
				personaId: pid,
				messages: [],
				createdAt: Date.now(),
				updatedAt: Date.now()
			};
			set({
				conversations: [conv],
				activeConversationId: conv.id,
				activePersonaId: pid
			});
			return;
		}
		const keeping = s.activeConversationId === id ? rest[0] : rest.find((c) => c.id === s.activeConversationId) ?? rest[0];
		set({
			conversations: rest,
			activeConversationId: keeping.id,
			activePersonaId: keeping.personaId
		});
	},
	touchConversation: (id) => {
		set({ conversations: get().conversations.map((c) => c.id === id ? {
			...c,
			updatedAt: Date.now()
		} : c).sort((a, b) => b.updatedAt - a.updatedAt) });
	},
	setActivePersona: (id) => set({ activePersonaId: id }),
	applyPersonaToActive: (id) => {
		const cid = get().activeConversationId;
		set({
			activePersonaId: id,
			conversations: get().conversations.map((c) => c.id === cid ? {
				...c,
				personaId: id,
				updatedAt: Date.now()
			} : c)
		});
	},
	upsertPersona: (persona) => {
		const list = get().personas;
		set({
			personas: list.some((p) => p.id === persona.id) ? list.map((p) => p.id === persona.id ? persona : p) : [persona, ...list],
			activePersonaId: persona.id
		});
		const cid = get().activeConversationId;
		if (cid) set({ conversations: get().conversations.map((c) => c.id === cid ? {
			...c,
			personaId: persona.id,
			updatedAt: Date.now()
		} : c) });
	},
	createPersona: () => {
		const now = Date.now();
		const persona = {
			...blankPersona(),
			id: uid("persona"),
			createdAt: now,
			updatedAt: now
		};
		set({
			personas: [persona, ...get().personas],
			activePersonaId: persona.id
		});
		return persona.id;
	},
	duplicatePersona: (id) => {
		const src = get().personas.find((p) => p.id === id);
		if (!src) return id;
		const now = Date.now();
		const copy = {
			...src,
			id: uid("persona"),
			name: `${src.name} — نسخة`,
			createdAt: now,
			updatedAt: now
		};
		set({
			personas: [copy, ...get().personas],
			activePersonaId: copy.id
		});
		return copy.id;
	},
	deletePersona: (id) => {
		const rest = get().personas.filter((p) => p.id !== id);
		if (!rest.length) return;
		set({
			personas: rest,
			activePersonaId: get().activePersonaId === id ? rest[0].id : get().activePersonaId,
			conversations: get().conversations.map((c) => c.personaId === id ? {
				...c,
				personaId: rest[0].id
			} : c)
		});
	},
	appendMessage: (conversationId, message) => {
		set({ conversations: get().conversations.map((c) => {
			if (c.id !== conversationId) return c;
			const titled = c.title === "حوار جديد" && message.role === "user" ? snippet(message.content, 36) : c.title;
			return {
				...c,
				title: titled,
				messages: [...c.messages, message],
				updatedAt: Date.now()
			};
		}).sort((a, b) => b.updatedAt - a.updatedAt) });
	},
	setMessageContent: (conversationId, messageId, content) => {
		set({ conversations: get().conversations.map((c) => c.id !== conversationId ? c : {
			...c,
			messages: c.messages.map((m) => m.id === messageId ? {
				...m,
				content
			} : m),
			updatedAt: Date.now()
		}) });
	},
	removeMessagesAfter: (conversationId, messageId) => {
		set({ conversations: get().conversations.map((c) => {
			if (c.id !== conversationId) return c;
			const idx = c.messages.findIndex((m) => m.id === messageId);
			if (idx < 0) return c;
			return {
				...c,
				messages: c.messages.slice(0, idx + 1),
				updatedAt: Date.now()
			};
		}) });
	},
	setStreamingId: (id) => set({ streamingId: id })
}), {
	name: "sahra-v1",
	skipHydration: true,
	partialize: (s) => ({
		conversations: s.conversations,
		personas: s.personas,
		activeConversationId: s.activeConversationId,
		activePersonaId: s.activePersonaId
	}),
	onRehydrateStorage: () => () => {
		useSahraStore.getState().hydrateDefaults();
	}
}));
function selectActive(s) {
	const conversation = s.conversations.find((c) => c.id === s.activeConversationId) ?? s.conversations[0] ?? null;
	return {
		conversation,
		persona: s.personas.find((p) => p.id === (conversation?.personaId ?? s.activePersonaId)) ?? s.personas[0] ?? null
	};
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1.5 block text-xs font-medium text-muted",
			children: label
		}), children]
	});
}
function PersonaDialog({ open, onOpenChange }) {
	const personas = useSahraStore((s) => s.personas);
	const activePersonaId = useSahraStore((s) => s.activePersonaId);
	const upsertPersona = useSahraStore((s) => s.upsertPersona);
	const createPersona = useSahraStore((s) => s.createPersona);
	const duplicatePersona = useSahraStore((s) => s.duplicatePersona);
	const deletePersona = useSahraStore((s) => s.deletePersona);
	const applyPersonaToActive = useSahraStore((s) => s.applyPersonaToActive);
	const [selectedId, setSelectedId] = (0, import_react.useState)(activePersonaId);
	const selected = (0, import_react.useMemo)(() => personas.find((p) => p.id === selectedId) ?? personas[0] ?? null, [personas, selectedId]);
	const [draft, setDraft] = (0, import_react.useState)(selected);
	(0, import_react.useEffect)(() => {
		if (open) setSelectedId(activePersonaId);
	}, [open, activePersonaId]);
	(0, import_react.useEffect)(() => {
		setDraft(selected);
	}, [selected]);
	function patch(key, value) {
		setDraft((d) => d ? {
			...d,
			[key]: value,
			updatedAt: Date.now()
		} : d);
	}
	function save(apply) {
		if (!draft) return;
		const next = {
			...draft,
			name: draft.name.trim() || "بلا اسم",
			updatedAt: Date.now()
		};
		upsertPersona(next);
		if (apply) applyPersonaToActive(next.id);
		onOpenChange(false);
	}
	if (!draft) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
			title: "شخصيات المساعد",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid min-h-[28rem] md:grid-cols-[220px_1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "border-b border-border p-3 md:border-b-0 md:border-e",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						className: "mb-2 w-full",
						onClick: () => {
							const id = createPersona();
							setSelectedId(id);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "شخصية جديدة"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-1",
						children: personas.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setSelectedId(p.id),
							className: cn("w-full rounded-xl px-3 py-2 text-start", p.id === draft.id ? "bg-elevated" : "hover:bg-elevated/50"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "truncate text-sm font-medium",
								children: p.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "truncate text-[0.7rem] text-subtle",
								children: [
									FRANKNESS_LABEL[p.frankness],
									" · ",
									p.tagline
								]
							})]
						}) }, p.id))
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4 p-4 sm:p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "الاسم",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: draft.name,
									onChange: (e) => patch("name", e.target.value)
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "جملة تعريف",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: draft.tagline,
									onChange: (e) => patch("tagline", e.target.value)
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "الدور",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: draft.role,
								onChange: (e) => patch("role", e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "النبرة",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: draft.tone,
									onChange: (e) => patch("tone", e.target.value)
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "الأسلوب",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: draft.style,
									onChange: (e) => patch("style", e.target.value)
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-2 flex items-baseline justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-medium text-muted",
									children: "مستوى الصراحة"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-fg",
									children: FRANKNESS_LABEL[draft.frankness]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "range",
								min: 1,
								max: 5,
								step: 1,
								value: draft.frankness,
								onChange: (e) => patch("frankness", Number(e.target.value)),
								className: "w-full accent-accent"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-[0.7rem] text-subtle",
								children: FRANKNESS_HINT[draft.frankness]
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "الحدود",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								rows: 3,
								value: draft.boundaries,
								onChange: (e) => patch("boundaries", e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "تعليمات إضافية",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								rows: 4,
								value: draft.instructions,
								onChange: (e) => patch("instructions", e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: `الحرارة ${draft.temperature.toFixed(2)}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "range",
								min: .2,
								max: 1.2,
								step: .05,
								value: draft.temperature,
								onChange: (e) => patch("temperature", Number(e.target.value)),
								className: "w-full accent-accent"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-2 border-t border-border pt-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "ghost",
									size: "sm",
									onClick: () => {
										const id = duplicatePersona(draft.id);
										setSelectedId(id);
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-3.5" }), "نسخ"]
								}), personas.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "ghost",
									size: "sm",
									className: "text-danger hover:text-danger",
									onClick: () => {
										const next = personas.find((p) => p.id !== draft.id);
										deletePersona(draft.id);
										setSelectedId(next?.id ?? null);
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" }), "حذف"]
								}) : null]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									size: "sm",
									onClick: () => onOpenChange(false),
									children: "إلغاء"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									onClick: () => save(true),
									children: "حفظ واستخدام"
								})]
							})]
						})
					]
				})]
			})
		})
	});
}
function Crescent({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: cn("size-7", className),
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "16",
			cy: "16",
			r: "15",
			fill: "currentColor",
			opacity: "0.08"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M19.2 6.4c-6.1.9-10.6 6.4-10.2 12.7.4 5.6 5 10 10.6 10.4-6.8.8-13.2-4.4-13.8-11.5C5.1 10.2 11 4.2 18.6 4c.2.8.5 1.6.6 2.4Z",
			fill: "currentColor"
		})]
	});
}
function Wordmark({ compact = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2.5 text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crescent, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "leading-none",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "font-display text-lg font-medium tracking-tight",
				children: "سهرة"
			}), !compact ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-0.5 text-[0.65rem] text-subtle",
				children: "Sahra"
			}) : null]
		})]
	});
}
var DAY_LABEL = {
	today: "اليوم",
	yesterday: "أمس",
	week: "هذا الأسبوع",
	older: "أقدم"
};
function Sidebar({ onOpenPersonas }) {
	const conversations = useSahraStore((s) => s.conversations);
	const personas = useSahraStore((s) => s.personas);
	const { conversation: active, persona } = useSahraStore(useShallow(selectActive));
	const newConversation = useSahraStore((s) => s.newConversation);
	const setActiveConversation = useSahraStore((s) => s.setActiveConversation);
	const deleteConversation = useSahraStore((s) => s.deleteConversation);
	const renameConversation = useSahraStore((s) => s.renameConversation);
	const [query, setQuery] = (0, import_react.useState)("");
	const [editingId, setEditingId] = (0, import_react.useState)(null);
	const [draft, setDraft] = (0, import_react.useState)("");
	const filtered = (0, import_react.useMemo)(() => {
		const q = query.trim();
		const list = q ? conversations.filter((c) => {
			const personaName = personas.find((p) => p.id === c.personaId)?.name ?? "";
			return c.title.includes(q) || personaName.includes(q) || c.messages.some((m) => m.content.includes(q));
		}) : conversations;
		const groups = [
			{
				key: "today",
				items: []
			},
			{
				key: "yesterday",
				items: []
			},
			{
				key: "week",
				items: []
			},
			{
				key: "older",
				items: []
			}
		];
		for (const c of list) groups.find((x) => x.key === groupDay(c.updatedAt))?.items.push(c);
		return groups.filter((g) => g.items.length);
	}, [
		conversations,
		personas,
		query
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col bg-surface",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex items-center justify-between px-4 pt-5 pb-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					className: "w-full justify-between",
					onClick: () => newConversation(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "حوار جديد" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageSquarePlus, { className: "size-4" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative mt-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 start-3 size-4 -translate-y-1/2 text-subtle" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: query,
						onChange: (e) => setQuery(e.target.value),
						placeholder: "ابحث في الجلسات",
						className: "ps-9",
						"aria-label": "بحث"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "mt-3 min-h-0 flex-1 overflow-y-auto px-2 pb-3 scrollbar-thin",
				children: filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-3 py-8 text-center text-sm text-subtle",
					children: "لا جلسات مطابقة"
				}) : filtered.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "px-3 pb-1.5 text-[0.7rem] font-medium tracking-wide text-subtle",
						children: DAY_LABEL[group.key]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-0.5",
						children: group.items.map((c) => {
							const p = personas.find((x) => x.id === c.personaId);
							const isActive = c.id === active?.id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: cn("group flex items-start gap-1 rounded-xl px-2 py-2", isActive ? "bg-elevated" : "hover:bg-elevated/60"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setActiveConversation(c.id),
									className: "min-w-0 flex-1 text-start",
									children: editingId === c.id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										autoFocus: true,
										value: draft,
										onChange: (e) => setDraft(e.target.value),
										onClick: (e) => e.stopPropagation(),
										onBlur: () => {
											renameConversation(c.id, draft);
											setEditingId(null);
										},
										onKeyDown: (e) => {
											if (e.key === "Enter") {
												renameConversation(c.id, draft);
												setEditingId(null);
											}
											if (e.key === "Escape") setEditingId(null);
										},
										className: "h-8 w-full rounded-lg bg-bg px-2 text-sm outline-none"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "truncate text-sm font-medium",
										children: c.title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-0.5 flex items-center gap-2 text-[0.7rem] text-subtle",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "truncate",
											children: p?.name ?? "سهرة"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "tabular-nums",
											children: formatRelative(c.updatedAt)
										})]
									})] })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex shrink-0 opacity-0 transition-opacity group-hover:opacity-100 group-focus-within:opacity-100 max-md:opacity-100",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "inline-flex size-8 items-center justify-center rounded-lg text-subtle hover:bg-bg hover:text-fg",
										"aria-label": "إعادة تسمية",
										onClick: () => {
											setEditingId(c.id);
											setDraft(c.title);
										},
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-3.5" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "inline-flex size-8 items-center justify-center rounded-lg text-subtle hover:bg-bg hover:text-danger",
										"aria-label": "حذف الجلسة",
										onClick: () => deleteConversation(c.id),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" })
									})]
								})]
							}) }, c.id);
						})
					})]
				}, group.key))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "border-t border-border p-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: onOpenPersonas,
					className: "flex w-full items-center justify-between rounded-xl bg-elevated px-3 py-2.5 text-start hover:shadow-[var(--shadow-border-hover)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[0.7rem] text-subtle",
							children: "الشخصية النشطة"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "truncate text-sm font-medium",
							children: persona?.name ?? "سهرة"
						})]
					}), persona ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "shrink-0 rounded-full bg-bg px-2 py-1 text-[0.65rem] text-muted",
						children: FRANKNESS_LABEL[persona.frankness]
					}) : null]
				})
			})
		]
	});
}
async function readChatStream(res, handlers, signal) {
	if (!res.ok) {
		let message = `تعذّر الاتصال (${res.status})`;
		try {
			const body = await res.json();
			if (body.error) message = body.error;
		} catch {}
		handlers.onError(message);
		return;
	}
	const reader = res.body?.getReader();
	if (!reader) {
		handlers.onError("تعذّر قراءة الرد.");
		return;
	}
	const decoder = new TextDecoder();
	let buffer = "";
	try {
		while (true) {
			if (signal.aborted) break;
			const { done, value } = await reader.read();
			if (done) break;
			buffer += decoder.decode(value, { stream: true });
			let sep;
			while ((sep = buffer.indexOf("\n")) >= 0) {
				const line = buffer.slice(0, sep).trim();
				buffer = buffer.slice(sep + 1);
				if (!line.startsWith("data:")) continue;
				const data = line.slice(5).trim();
				if (data === "[DONE]") {
					handlers.onDone();
					return;
				}
				try {
					const json = JSON.parse(data);
					if (json.error?.message) {
						handlers.onError(json.error.message);
						return;
					}
					const piece = json.choices?.[0]?.delta?.content;
					if (piece) handlers.onDelta(piece);
				} catch {}
			}
		}
		handlers.onDone();
	} catch (err) {
		if (signal.aborted) {
			handlers.onDone();
			return;
		}
		handlers.onError(err instanceof Error ? err.message : "انقطع البث.");
	}
}
function ChatApp() {
	const sidebarOpen = useSahraStore((s) => s.sidebarOpen);
	const setSidebarOpen = useSahraStore((s) => s.setSidebarOpen);
	const { conversation, persona } = useSahraStore(useShallow(selectActive));
	const streamingId = useSahraStore((s) => s.streamingId);
	const error = useSahraStore((s) => s.error);
	const setError = useSahraStore((s) => s.setError);
	const setMessageContent = useSahraStore((s) => s.setMessageContent);
	const setStreamingId = useSahraStore((s) => s.setStreamingId);
	const applyPersonaToActive = useSahraStore((s) => s.applyPersonaToActive);
	const personas = useSahraStore((s) => s.personas);
	const newConversation = useSahraStore((s) => s.newConversation);
	const [draft, setDraft] = (0, import_react.useState)("");
	const [personaOpen, setPersonaOpen] = (0, import_react.useState)(false);
	const abortRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		useSahraStore.persist.rehydrate();
	}, []);
	(0, import_react.useEffect)(() => {
		function onKey(e) {
			if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "n") {
				e.preventDefault();
				newConversation();
			}
			if (e.key === "Escape") setSidebarOpen(false);
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [newConversation, setSidebarOpen]);
	(0, import_react.useEffect)(() => {
		return () => abortRef.current?.abort();
	}, []);
	async function send(text, mode = "new") {
		const state = useSahraStore.getState();
		const active = selectActive(state);
		const conv = active.conversation;
		const p = active.persona;
		if (!conv || !p) return;
		const content = text.trim().slice(0, MAX_MESSAGE_CHARS);
		if (!content) return;
		let prior = conv.messages;
		if (mode === "regen") {
			if (prior.at(-1)?.role === "assistant") prior = prior.slice(0, -1);
			if (prior.at(-1)?.role === "user") prior = prior.slice(0, -1);
		}
		const userMsg = {
			id: uid("msg"),
			role: "user",
			content,
			createdAt: Date.now()
		};
		const assistantMsg = {
			id: uid("msg"),
			role: "assistant",
			content: "",
			createdAt: Date.now()
		};
		const titled = conv.title === "حوار جديد" ? snippet(content, 36) : conv.title;
		useSahraStore.setState({
			conversations: state.conversations.map((c) => c.id === conv.id ? {
				...c,
				title: titled,
				messages: [
					...prior,
					userMsg,
					assistantMsg
				],
				updatedAt: Date.now()
			} : c).sort((a, b) => b.updatedAt - a.updatedAt),
			streamingId: assistantMsg.id,
			error: null
		});
		setDraft("");
		const payloadMessages = [...prior, userMsg].slice(-36).map((m) => ({
			role: m.role,
			content: m.content
		}));
		abortRef.current?.abort();
		const ac = new AbortController();
		abortRef.current = ac;
		let assembled = "";
		try {
			await readChatStream(await fetch("/api/chat", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				signal: ac.signal,
				body: JSON.stringify({
					conversationId: conv.id,
					messages: payloadMessages,
					persona: {
						name: p.name,
						role: p.role,
						tone: p.tone,
						style: p.style,
						frankness: p.frankness,
						boundaries: p.boundaries,
						instructions: p.instructions,
						temperature: p.temperature
					}
				})
			}), {
				onDelta: (piece) => {
					assembled += piece;
					setMessageContent(conv.id, assistantMsg.id, assembled);
				},
				onDone: () => {
					setStreamingId(null);
					if (!assembled.trim()) setMessageContent(conv.id, assistantMsg.id, "لم يصل رد. أعد المحاولة.");
				},
				onError: (message) => {
					setStreamingId(null);
					setError(message);
					if (!assembled) setMessageContent(conv.id, assistantMsg.id, "");
				}
			}, ac.signal);
		} catch (err) {
			if (ac.signal.aborted) {
				setStreamingId(null);
				return;
			}
			setStreamingId(null);
			setError(err instanceof Error ? err.message : "تعذّر الإرسال.");
		}
	}
	function stop() {
		abortRef.current?.abort();
		setStreamingId(null);
	}
	function regenerate() {
		const lastUser = [...conversation?.messages ?? []].reverse().find((m) => m.role === "user");
		if (!lastUser) return;
		send(lastUser.content, "regen");
	}
	const streaming = streamingId !== null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh overflow-hidden bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
				className: "hidden w-[18.5rem] shrink-0 border-e border-border md:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sidebar, { onOpenPersonas: () => {
					setPersonaOpen(true);
					setSidebarOpen(false);
				} })
			}),
			sidebarOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-40 md:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "absolute inset-0 bg-bg/70",
					"aria-label": "إغلاق القائمة",
					onClick: () => setSidebarOpen(false)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-y-0 start-0 w-[min(100%,18.5rem)] shadow-[var(--shadow-float)]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sidebar, { onOpenPersonas: () => {
						setPersonaOpen(true);
						setSidebarOpen(false);
					} })
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 flex-1 flex-col",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "flex h-14 shrink-0 items-center gap-2 border-b border-border px-2 sm:px-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon-sm",
								className: "md:hidden",
								onClick: () => setSidebarOpen(!sidebarOpen),
								"aria-label": "الجلسات",
								children: sidebarOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "truncate text-sm font-medium",
									children: conversation?.title ?? "سهرة"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "truncate text-[0.7rem] text-subtle",
									children: persona?.tagline
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "sr-only",
										htmlFor: "persona-select",
										children: "الشخصية"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
										id: "persona-select",
										value: persona?.id ?? "",
										onChange: (e) => applyPersonaToActive(e.target.value),
										className: "h-9 max-w-36 rounded-lg bg-transparent px-2 text-sm text-fg outline-none hover:bg-elevated",
										children: personas.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: p.id,
											className: "bg-surface text-fg",
											children: p.name
										}, p.id))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										variant: "ghost",
										size: "sm",
										onClick: () => setPersonaOpen(true),
										"aria-label": "تعديل الشخصية",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, { className: "size-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "hidden sm:inline",
											children: "تعديل"
										})]
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageList, {
						messages: conversation?.messages ?? [],
						streamingId,
						persona,
						error,
						onPickStarter: (text) => {
							send(text);
						},
						onRegenerate: regenerate
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Composer, {
						value: draft,
						onChange: setDraft,
						onSubmit: () => void send(draft),
						onStop: stop,
						disabled: !conversation || !persona,
						streaming,
						placeholder: persona ? `اكتب إلى ${persona.name}…` : "اكتب رسالتك…"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonaDialog, {
				open: personaOpen,
				onOpenChange: setPersonaOpen
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatApp, {});
}
//#endregion
export { Home as component };
