//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BrsZU9mI.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/api/chat"],
		preloads: ["/assets/index-CU78HJPv.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CU78HJPv.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BiNiYza0.js"]
	}
} });
//#endregion
export { tsrStartManifest };
